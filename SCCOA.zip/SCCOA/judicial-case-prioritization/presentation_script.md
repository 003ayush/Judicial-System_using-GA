# 🎤 Demo Script: AI Court Scheduler Presentation

*Use this script as a step-by-step guide when presenting to your professor (Mam). It explains exactly what to click, what to say, and why we used specific technologies.*

---

## 1. Introduction (Stay on the Dashboard)
**🗣️ What to say:**
> "Good morning Mam. For my FA-1 project, I have developed the **AI Court Scheduler**. The problem we are solving is the massive backlog in judicial courts. Traditionally, courts schedule cases using a First-In, First-Out (FIFO) method, which means urgent cases—like child custody or severe constitutional matters—often get stuck behind routine commercial disputes."

> "To solve this, we built a hybrid AI that combines **Soft Computing (Fuzzy Logic)** with an **Optimization Algorithm (Genetic Algorithm)**. Let me show you how it works."

---

## 2. Dashboard Overview (📊 Dashboard Tab)
**🖱️ Action:** *Point to the 4 workflow blocks and the graphs.*
**🗣️ What to say:**
> "This is the executive dashboard. As you can see, our system follows a 4-step workflow: Case Profiling, AI Urgency Scoring, Schedule Optimization, and Final Output."

> "At a glance, the KPIs show exactly how many cases are pending, what the average urgency score is, and exactly how many cases are 'Critical'. We used the **Matplotlib** library to generate these priority distribution charts dynamically."

---

## 3. Managing Data (📁 Case Data Tab)
**🖱️ Action:** *Click on the 'Case Data' tab on the left.*
**🗣️ What to say:**
> "Here in the Case Data tab, the court registry can view all pending cases. We have implemented a synthetic data generator so we can test the algorithm on realistic court data."

> "We also implemented a **CSV Upload feature** here. If a clerk uploads a real docket, our AI instantly ingests the Pandas dataframe, calculates the priority scores for every single case, and updates the entire application."

---

## 4. The Soft Computing Brain (🧠 AI Evaluator Tab)
**🖱️ Action:** *Click on the 'AI Evaluator' tab. Move the sliders around so the priority gauge changes.*
**🗣️ What to say:**
> "This is the core of our Soft Computing approach. To score how urgent a case is, we did **not** use a Deep Learning Neural Network. Neural networks are 'Black Boxes' and cannot be used in a legal setting because judges need to know *why* a decision was made."

> "Instead, we built a **Mamdani Fuzzy Inference System (FIS)** from scratch. As I move these sliders—changing the Case Age, Severity, and Vulnerability—you can see the Priority Score change in real-time."

**🖱️ Action:** *Point to the 'Explainable AI' text box below the score.*
**🗣️ What to say:**
> "Because we used Fuzzy Logic, our AI is 100% explainable. Right here, the AI prints out exactly *why* this score was given in plain English, citing the exact variables that triggered it."

**🖱️ Action:** *Click on the 'Complete Judicial Rule Base' tab.*
**🗣️ What to say:**
> "If you look at the Rule Base, you can see the 16 IF-THEN rules we programmed into the system. For example, *'IF Severity is High AND Vulnerability is High THEN Priority is Critical'*. The system uses the 'Centroid method' to mathematically combine these rules into a final score from 0 to 100."

---

## 5. The Optimization Algorithm (🧬 AI Scheduler Tab)
**🖱️ Action:** *Click on the 'AI Scheduler' tab. Click the 'Run Timetable Optimization' button.*
**🗣️ What to say:**
> "Finally, we move to scheduling. Just sorting cases by priority isn't enough, because courtrooms have strict daily capacity limits (like 6 hours a day), and scheduling is an NP-Hard combinatorial problem."

> "To solve this, we used a **Permutation Genetic Algorithm (GA)**. We specifically used **Order Crossover (OX)** because standard crossover would create invalid schedules with duplicate cases."

**🖱️ Action:** *Wait for the progress bar to finish and point to the generated calendar.*
**🗣️ What to say:**
> "Our objective function penalizes the algorithm if it schedules high-priority cases late, or if it exceeds the daily courtroom capacity. As you can see, the GA has evolved the perfect schedule, assigning cases perfectly across Courtroom 1, Courtroom 2, and the Special Bench. This reduces lateness by over 50% compared to the traditional sorting methods."

---

## 6. Conclusion
**🗣️ What to say:**
> "In conclusion Mam, by combining the explainability of **Fuzzy Logic** with the heavy-lifting optimization of a **Genetic Algorithm**, we have created a transparent, ethical, and highly efficient solution to the judicial backlog crisis. Thank you!"
