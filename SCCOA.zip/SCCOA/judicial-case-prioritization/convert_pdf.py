import re
from markdown_pdf import Section, MarkdownPdf

def convert(md_file, pdf_file):
    pdf = MarkdownPdf()
    with open(md_file, 'r', encoding='utf-8') as f:
        content = f.read()
    # Remove markdown links that are just anchor links to avoid crash
    content = re.sub(r'\[(.*?)\]\(#.*?\)', r'\1', content)
    pdf.add_section(Section(content))
    pdf.save(pdf_file)

convert('presentation_script.md', 'presentation_script.pdf')
