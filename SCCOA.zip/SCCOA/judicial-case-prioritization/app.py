"""
Judicial Case Prioritization & Court Scheduling System
======================================================
Explainable Decision Support Prototype
Department: CSE (AI & ML)

A human-in-the-loop, explainable decision support system combining:
1. Mamdani Fuzzy Inference System (FIS) for transparent case urgency scoring
2. Genetic Algorithm (OX Crossover) for conflict-free court timetable optimization
"""

import streamlit as st
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import time
import sys
import os
from pathlib import Path

sys.path.insert(0, os.path.dirname(__file__))

from src.config import (
    RANDOM_SEED, NUM_CASES, FUZZY_INPUTS, FUZZY_INPUT_MFS,
    FUZZY_OUTPUT_MFS, FUZZY_INPUT_RANGE, FUZZY_OUTPUT_RANGE,
    GA_POPULATION_SIZE, GA_GENERATIONS, GA_CROSSOVER_RATE,
    GA_MUTATION_RATE, FEATURE_RANGES, DAILY_CAPACITY_HOURS,
    FIGURES_DIR, TABLES_DIR, SENSITIVITY_PARAMS,
)
from src.data_generator import generate_cases, save_dataset
from src.preprocessing import preprocess, FEATURE_DESCRIPTIONS, get_descriptive_stats, validate_dataset
from src.fuzzy_engine import (
    compute_priority, compute_all_priorities, get_mf_plot_data, fuzzify_input,
)
from src.fuzzy_rules import FUZZY_RULES, get_rules_table
from src.objective import compute_objective
from src.genetic_algorithm import GeneticAlgorithm
from src.baselines import run_all_baselines
from src.evaluation import (
    compare_methods, run_ga_experiment, run_repeated_trials,
    compute_trial_statistics, run_sensitivity_analysis
)
from src.visualization import (
    plot_input_membership_functions, plot_output_membership_functions,
    plot_priority_distribution, plot_comparison_bar, plot_convergence,
    plot_repeated_trials, plot_sensitivity,
    _apply_style, _get_color,
)
from src.utils import ACADEMIC_DISCLAIMER, format_number, format_duration


# ── Page Configuration ────────────────────────────────────────

st.set_page_config(
    page_title="Judicial Case Prioritization AI",
    page_icon="⚖️",
    layout="wide",
    initial_sidebar_state="expanded",
)


# ── Clean & Modern Custom CSS ─────────────────────────────────

st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;600&display=swap');

    html, body, [class*="css"] {
        font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    }

    /* Background and Layout */
    .stApp {
        background: radial-gradient(circle at 10% 20%, #111A2E 0%, #0B1120 50%, #070B14 100%);
        color: #F1F5F9;
    }

    /* Top banner card */
    .hero-banner {
        background: linear-gradient(135deg, rgba(30, 41, 59, 0.75) 0%, rgba(15, 23, 42, 0.85) 100%);
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 16px;
        padding: 24px 28px;
        margin-bottom: 24px;
        box-shadow: 0 10px 30px -10px rgba(0, 0, 0, 0.5);
        backdrop-filter: blur(12px);
    }

    /* Badges & Pills */
    .badge-pill {
        display: inline-block;
        padding: 4px 12px;
        border-radius: 9999px;
        font-size: 0.75rem;
        font-weight: 700;
        letter-spacing: 0.5px;
        text-transform: uppercase;
        margin-right: 8px;
    }
    .badge-status {
        background: rgba(16, 185, 129, 0.15);
        color: #10B981;
        border: 1px solid rgba(16, 185, 129, 0.3);
    }
    .badge-prototype {
        background: rgba(99, 102, 241, 0.15);
        color: #818CF8;
        border: 1px solid rgba(99, 102, 241, 0.3);
    }

    /* Metric Cards */
    div[data-testid="stMetric"] {
        background: linear-gradient(135deg, rgba(30, 41, 59, 0.6) 0%, rgba(15, 23, 42, 0.7) 100%);
        border: 1px solid rgba(255, 255, 255, 0.08);
        border-radius: 14px;
        padding: 18px 20px;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.25);
        backdrop-filter: blur(8px);
        transition: transform 0.2s ease, border-color 0.2s ease;
    }
    div[data-testid="stMetric"]:hover {
        transform: translateY(-2px);
        border-color: rgba(99, 102, 241, 0.4);
    }
    div[data-testid="stMetric"] label {
        color: #94A3B8 !important;
        font-size: 0.85rem !important;
        font-weight: 600 !important;
        letter-spacing: 0.3px;
    }
    div[data-testid="stMetric"] div[data-testid="stMetricValue"] {
        color: #F8FAFC !important;
        font-weight: 800 !important;
        font-size: 1.85rem !important;
        letter-spacing: -0.5px;
    }

    /* Sidebar */
    section[data-testid="stSidebar"] {
        background: #0B1120 !important;
        border-right: 1px solid rgba(255, 255, 255, 0.08);
    }

    /* Headers */
    h1 {
        color: #F8FAFC !important;
        font-weight: 800 !important;
        letter-spacing: -0.5px !important;
    }
    h2, h3, h4 {
        color: #E2E8F0 !important;
        font-weight: 700 !important;
    }

    /* Clean Info Box / Alerts */
    .clean-callout {
        background: rgba(15, 23, 42, 0.7);
        border: 1px solid rgba(255, 255, 255, 0.08);
        border-left: 4px solid #6366F1;
        border-radius: 10px;
        padding: 14px 18px;
        margin: 14px 0;
        font-size: 0.92rem;
        line-height: 1.5;
        color: #CBD5E1;
    }
    .alert-disclaimer {
        background: rgba(245, 158, 11, 0.08);
        border: 1px solid rgba(245, 158, 11, 0.25);
        border-left: 4px solid #F59E0B;
        border-radius: 10px;
        padding: 12px 16px;
        margin: 14px 0;
        font-size: 0.85rem;
        color: #FDE68A;
    }

    /* Step Pipeline Cards */
    .step-card {
        background: rgba(30, 41, 59, 0.5);
        border: 1px solid rgba(255, 255, 255, 0.08);
        border-radius: 12px;
        padding: 14px 16px;
        text-align: center;
        transition: all 0.2s ease;
    }
    .step-card:hover {
        background: rgba(30, 41, 59, 0.8);
        border-color: rgba(99, 102, 241, 0.5);
    }
    .step-num {
        display: inline-block;
        width: 24px;
        height: 24px;
        line-height: 24px;
        border-radius: 50%;
        background: #6366F1;
        color: white;
        font-size: 0.75rem;
        font-weight: 700;
        margin-bottom: 6px;
    }

    /* Custom Priority Gauges */
    .priority-badge-box {
        text-align: center;
        padding: 24px 20px;
        border-radius: 16px;
        backdrop-filter: blur(10px);
        margin: 10px 0;
        box-shadow: 0 10px 25px rgba(0, 0, 0, 0.3);
    }

    /* Buttons */
    .stButton > button {
        border-radius: 10px;
        font-weight: 600;
        font-size: 0.92rem;
        padding: 10px 20px;
        transition: all 0.2s ease;
        border: 1px solid rgba(255, 255, 255, 0.12);
    }
    .stButton > button:hover {
        transform: translateY(-1px);
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.3);
    }

    /* Tabs */
    .stTabs [data-baseweb="tab-list"] {
        gap: 8px;
        background: rgba(15, 23, 42, 0.6);
        padding: 6px;
        border-radius: 12px;
        border: 1px solid rgba(255, 255, 255, 0.06);
    }
    .stTabs [data-baseweb="tab"] {
        background: transparent;
        border-radius: 8px;
        color: #94A3B8;
        font-weight: 600;
        font-size: 0.88rem;
        padding: 8px 16px;
        border: none;
    }
    .stTabs [aria-selected="true"] {
        background: #1E293B !important;
        color: #FFFFFF !important;
        border: 1px solid rgba(255, 255, 255, 0.12);
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.25);
    }

    /* Sliders & Inputs */
    div[data-testid="stSlider"] label {
        font-size: 0.88rem;
        font-weight: 600;
        color: #CBD5E1;
    }
</style>
""", unsafe_allow_html=True)


# ── Session State Initialization ──────────────────────────────

def init_state():
    if 'dataset' not in st.session_state:
        st.session_state.dataset = None
    if 'processed' not in st.session_state:
        st.session_state.processed = None
    if 'priorities' not in st.session_state:
        st.session_state.priorities = None
    if 'results' not in st.session_state:
        st.session_state.results = None
    # Preset simulator values
    if 'sim_age' not in st.session_state:
        st.session_state.sim_age = 5.0
    if 'sim_sev' not in st.session_state:
        st.session_state.sim_sev = 6
    if 'sim_comp' not in st.session_state:
        st.session_state.sim_comp = 5
    if 'sim_pub' not in st.session_state:
        st.session_state.sim_pub = 5
    if 'sim_vuln' not in st.session_state:
        st.session_state.sim_vuln = 6

init_state()


# ── Helper Functions ──────────────────────────────────────────

def load_or_generate_data(num_cases=NUM_CASES, seed=RANDOM_SEED):
    """Generate and preprocess dataset, computing fuzzy priority scores."""
    df = generate_cases(num_cases, seed)
    processed, report = preprocess(df)
    scores = compute_all_priorities(processed)
    processed['priority_score'] = scores
    st.session_state.dataset = df
    st.session_state.processed = processed
    st.session_state.priorities = np.array(scores)
    return processed, report


def get_priority_badge(score: float):
    """Get badge label, colors and tier level for a priority score."""
    if score >= 75:
        return "CRITICAL URGENCY", "#EF4444", "rgba(239, 68, 68, 0.15)", "🚨"
    elif score >= 60:
        return "HIGH PRIORITY", "#F97316", "rgba(249, 115, 22, 0.15)", "⚠️"
    elif score >= 40:
        return "MODERATE PRIORITY", "#38BDF8", "rgba(56, 189, 248, 0.15)", "⚖️"
    else:
        return "ROUTINE DOCKET", "#10B981", "rgba(16, 185, 129, 0.15)", "📄"


def get_case_type_color(case_type: str) -> str:
    """Return consistent accent color for judicial case categories."""
    palette = {
        "Civil": "#38BDF8",
        "Criminal": "#F43F5E",
        "Family": "#10B981",
        "Commercial": "#F59E0B",
        "Constitutional": "#A855F7",
    }
    return palette.get(case_type, "#94A3B8")


# ── Sidebar Navigation ────────────────────────────────────────

with st.sidebar:
    st.markdown("""
        <div style="display:flex; align-items:center; gap:10px; margin-bottom:12px;">
            <span style="font-size:28px;">⚖️</span>
            <div>
                <h3 style="margin:0; font-size:1.15rem; color:#F8FAFC;">CourtPrioritize</h3>
                <span style="font-size:0.75rem; color:#94A3B8;">Fuzzy-Hybrid AI Scheduler</span>
            </div>
        </div>
    """, unsafe_allow_html=True)

    page = st.radio(
        "Navigation",
        [
            "📊 Dashboard",
            "📁 Case Data",
            "🧠 AI Evaluator",
            "🧬 AI Scheduler",
        ],
        label_visibility="collapsed"
    )

    st.markdown("---")

    # Quick System Stats in Sidebar
    if st.session_state.processed is not None:
        p_df = st.session_state.processed
        p_scores = st.session_state.priorities
        st.markdown("<p style='font-size:0.8rem; font-weight:700; color:#94A3B8; margin-bottom:8px;'>ACTIVE DOCKET STATS</p>", unsafe_allow_html=True)
        col_sb1, col_sb2 = st.columns(2)
        with col_sb1:
            st.metric("Total Cases", len(p_df))
            st.metric("Critical", int((p_scores >= 75).sum()))
        with col_sb2:
            st.metric("Avg Score", f"{p_scores.mean():.1f}")
            st.metric("High Urg", int(((p_scores >= 60) & (p_scores < 75)).sum()))

    st.markdown("---")
    st.markdown("""
        <div style="text-align:center; color:#64748B; font-size:0.75rem; line-height:1.4;">
            <strong>CourtPrioritize AI</strong><br>
            Dept. of CSE (AI & ML)<br>
            Academic Decision Support Prototype
        </div>
    """, unsafe_allow_html=True)


# Auto-generate baseline dataset if not loaded
if st.session_state.processed is None:
    load_or_generate_data()

df = st.session_state.processed
priorities = st.session_state.priorities


# ══════════════════════════════════════════════════════════════
# PAGE 1: DASHBOARD
# ══════════════════════════════════════════════════════════════

if page == "📊 Dashboard":
    # Hero Title Banner
    st.markdown("""
        <div class="hero-banner">
            <div style="display:flex; justify-content:space-between; align-items:flex-start; flex-wrap:wrap; gap:12px;">
                <div>
                    <span class="badge-pill badge-status">● SYSTEM ACTIVE</span>
                    <span class="badge-pill badge-prototype">EXPLAINABLE AI PROTOTYPE</span>
                    <h1 style="margin:10px 0 4px 0; font-size:2.0rem;">AI Court Scheduler</h1>
                    <p style="margin:0; color:#94A3B8; font-size:0.95rem; max-width:850px;">
                        Transparent, multi-criteria court backlog scheduling powered by <strong>Mamdani Fuzzy Logic</strong> for case urgency assessment and <strong>Genetic Algorithms</strong> for courtroom conflict optimization.
                    </p>
                </div>
            </div>
        </div>
    """, unsafe_allow_html=True)

    # Disclaimer Note
    st.markdown("""
        <div class="alert-disclaimer">
            <strong>⚠️ Academic Research Notice:</strong> This prototype evaluates synthetic judicial records to demonstrate hybrid optimization. It operates purely as an advisory scheduling aid and does <strong>not</strong> make substantive legal decisions, predict trial outcomes, or replace judicial discretion.
        </div>
    """, unsafe_allow_html=True)

    # Interactive 4-Step Pipeline Bar
    st.markdown("#### System Workflow Overview")
    s1, s2, s3, s4 = st.columns(4)
    with s1:
        st.markdown("""
            <div class="step-card">
                <span class="step-num">1</span>
                <div style="font-weight:700; color:#F1F5F9; font-size:0.9rem;">Case Profiling</div>
                <div style="color:#94A3B8; font-size:0.78rem;">Reads case details like age, severity, and complexity</div>
            </div>
        """, unsafe_allow_html=True)
    with s2:
        st.markdown("""
            <div class="step-card">
                <span class="step-num">2</span>
                <div style="font-weight:700; color:#F1F5F9; font-size:0.9rem;">AI Urgency Scoring</div>
                <div style="color:#94A3B8; font-size:0.78rem;">Calculates a fair priority score from 0 to 100</div>
            </div>
        """, unsafe_allow_html=True)
    with s3:
        st.markdown("""
            <div class="step-card">
                <span class="step-num">3</span>
                <div style="font-weight:700; color:#F1F5F9; font-size:0.9rem;">Schedule Optimization</div>
                <div style="color:#94A3B8; font-size:0.78rem;">Generates a conflict-free timetable using AI</div>
            </div>
        """, unsafe_allow_html=True)
    with s4:
        st.markdown("""
            <div class="step-card">
                <span class="step-num">4</span>
                <div style="font-weight:700; color:#F1F5F9; font-size:0.9rem;">Final Output</div>
                <div style="color:#94A3B8; font-size:0.78rem;">The complete daily calendar for the courtrooms</div>
            </div>
        """, unsafe_allow_html=True)

    st.markdown("<div style='height:16px;'></div>", unsafe_allow_html=True)

    # KPI Metric Row
    total_cases = len(df)
    avg_priority = priorities.mean()
    critical_count = int((priorities >= 75).sum())
    high_count = int(((priorities >= 60) & (priorities < 75)).sum())
    total_hours = df['hearing_duration'].sum()

    m1, m2, m3, m4 = st.columns(4)
    with m1:
        st.metric("Total Pending Cases", f"{total_cases:,}", help="Total number of active synthetic cases in current docket")
    with m2:
        st.metric("Average Urgency Score", f"{avg_priority:.1f} / 100", help="Mean Mamdani fuzzy priority score across docket")
    with m3:
        st.metric("Urgent & Critical Cases", f"{critical_count + high_count:,}", delta=f"{((critical_count+high_count)/total_cases)*100:.1f}% of docket", help="Cases with score >= 60 requiring expedited listing")
    with m4:
        st.metric("Total Hearing Time", f"{total_hours:,.1f} hrs", help=f"Estimated backlog workload (~{total_hours/DAILY_CAPACITY_HOURS:.1f} court days)")

    st.markdown("---")

    # Visual Charts Row
    c_left, c_right = st.columns(2)

    with c_left:
        st.markdown("### Priority Distribution by Case Category")
        st.caption("Distribution of fuzzy urgency scores across legal case domains")
        _apply_style()
        fig_dist, ax_dist = plt.subplots(figsize=(7, 4.2))
        for ct in sorted(df['case_type'].unique()):
            mask = df['case_type'] == ct
            ax_dist.hist(
                priorities[mask], bins=16, alpha=0.65,
                label=ct, color=get_case_type_color(ct), edgecolor="none"
            )
        ax_dist.set_xlabel("Fuzzy Priority Score (0 = Routine, 100 = Critical)", fontsize=9)
        ax_dist.set_ylabel("Number of Cases", fontsize=9)
        ax_dist.legend(loc="upper right", fontsize=8, framealpha=0.4)
        ax_dist.grid(True, alpha=0.25)
        fig_dist.tight_layout()
        st.pyplot(fig_dist)
        plt.close(fig_dist)

    with c_right:
        st.markdown("### Docket Composition & Hearing Volume")
        st.caption("Case counts and cumulative scheduled hearing hours per category")
        _apply_style()
        fig_bar, ax_bar = plt.subplots(figsize=(7, 4.2))
        type_summary = df.groupby('case_type').agg(
            count=('case_id', 'count'),
            hours=('hearing_duration', 'sum')
        ).reindex(sorted(df['case_type'].unique()))

        bars = ax_bar.bar(
            type_summary.index, type_summary['count'],
            color=[get_case_type_color(ct) for ct in type_summary.index],
            width=0.55, edgecolor="none"
        )
        for bar, count, hours in zip(bars, type_summary['count'], type_summary['hours']):
            ax_bar.text(
                bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.8,
                f"{count} ({hours:.0f}h)", ha='center', fontsize=8.5, fontweight='bold', color="#F1F5F9"
            )
        ax_bar.set_ylabel("Case Count", fontsize=9)
        ax_bar.set_ylim(0, max(type_summary['count']) * 1.18)
        ax_bar.grid(True, axis='y', alpha=0.25)
        fig_bar.tight_layout()
        st.pyplot(fig_bar)
        plt.close(fig_bar)

    st.markdown("---")

    # Top Urgent Cases Queue
    st.markdown("### 🚨 Highest Priority Cases Pending Hearing")
    st.caption("Top 10 cases prioritized by the Mamdani Fuzzy Inference Engine")

    top_cases = df.nlargest(10, 'priority_score').copy()
    display_top = pd.DataFrame({
        "Case ID": top_cases['case_id'],
        "Category": top_cases['case_type'],
        "Pendency Age (Yrs)": top_cases['age_years'].round(1),
        "Severity (1-10)": top_cases['severity'],
        "Vulnerability (1-10)": top_cases['vulnerability'],
        "Public Interest (1-10)": top_cases['public_interest'],
        "Est. Hours": top_cases['hearing_duration'].round(1),
        "Fuzzy Priority": top_cases['priority_score'].round(1),
        "Urgency Tier": [get_priority_badge(s)[0] for s in top_cases['priority_score']],
    })
    st.dataframe(display_top, width="stretch", hide_index=True)


# ══════════════════════════════════════════════════════════════
# PAGE 2: DATASET EXPLORER
# ══════════════════════════════════════════════════════════════

elif page == "📁 Case Data":
    st.markdown("""
        <div class="hero-banner">
            <h1 style="margin:0 0 6px 0; font-size:1.8rem;">📁 Case Data</h1>
            <p style="margin:0; color:#94A3B8; font-size:0.92rem;">
                Inspect, filter, search, and export the synthetic judicial case dataset calibrated with realistic court backlog parameters.
            </p>
        </div>
    """, unsafe_allow_html=True)

    # Dataset Upload Controls
    with st.expander("📂 Upload Custom Docket (CSV)", expanded=False):
        st.markdown("Upload your own list of court cases. Ensure it contains the following columns: `case_id`, `case_type`, `age_years`, `severity`, `complexity`, `vulnerability`, `public_interest`, `hearing_duration`, `target_day`.")
        uploaded_file = st.file_uploader("Choose a CSV file", type=["csv"])
        if uploaded_file is not None:
            try:
                new_df = pd.read_csv(uploaded_file)
                if st.button("Process Uploaded CSV", type="primary"):
                    with st.spinner("Processing custom docket..."):
                        processed, report = preprocess(new_df)
                        scores = compute_all_priorities(processed)
                        processed['priority_score'] = scores
                        st.session_state.dataset = new_df
                        st.session_state.processed = processed
                        st.session_state.priorities = np.array(scores)
                        st.session_state.results = None
                    st.success("Successfully loaded custom docket!")
                    st.rerun()
            except Exception as e:
                st.error(f"Error reading CSV: {e}")

    # Dataset Generation Controls in Expandable Card
    with st.expander("⚙️ Docket Generation Settings (Generate New Sample)", expanded=False):
        c_ctrl1, c_ctrl2, c_ctrl3 = st.columns([2, 2, 1])
        with c_ctrl1:
            num_cases_input = st.slider("Number of synthetic cases", 50, 500, len(df), step=10)
        with c_ctrl2:
            seed_input = st.number_input("Random generation seed", value=RANDOM_SEED, step=1)
        with c_ctrl3:
            st.markdown("<div style='height:28px;'></div>", unsafe_allow_html=True)
            if st.button("🔄 Generate Docket", width="stretch", type="primary"):
                with st.spinner("Generating reproducible case sample..."):
                    load_or_generate_data(num_cases_input, seed_input)
                st.success(f"Generated {num_cases_input} cases with seed {seed_input}!")
                st.rerun()

    # Filters Bar
    f_col1, f_col2, f_col3 = st.columns([2, 2, 2])
    with f_col1:
        selected_types = st.multiselect(
            "Filter by Case Category",
            options=sorted(df['case_type'].unique().tolist()),
            default=sorted(df['case_type'].unique().tolist()),
        )
    with f_col2:
        priority_filter = st.selectbox(
            "Filter by Priority Tier",
            options=["All Priority Levels", "Critical Urgency (≥ 75)", "High Priority (60 - 74)", "Moderate Priority (40 - 59)", "Routine Docket (< 40)"],
            index=0,
        )
    with f_col3:
        search_query = st.text_input("🔍 Search by Case ID", placeholder="e.g. CASE_0042")

    # Apply Filters
    filtered = df[df['case_type'].isin(selected_types)].copy()
    if priority_filter == "Critical Urgency (≥ 75)":
        filtered = filtered[filtered['priority_score'] >= 75]
    elif priority_filter == "High Priority (60 - 74)":
        filtered = filtered[(filtered['priority_score'] >= 60) & (filtered['priority_score'] < 75)]
    elif priority_filter == "Moderate Priority (40 - 59)":
        filtered = filtered[(filtered['priority_score'] >= 40) & (filtered['priority_score'] < 60)]
    elif priority_filter == "Routine Docket (< 40)":
        filtered = filtered[filtered['priority_score'] < 40]

    if search_query.strip():
        filtered = filtered[filtered['case_id'].str.contains(search_query.strip(), case=False, na=False)]

    # Quick summary of filtered subset
    kpi_f1, kpi_f2, kpi_f3, kpi_f4 = st.columns(4)
    with kpi_f1:
        st.metric("Matching Cases", f"{len(filtered):,} of {len(df):,}")
    with kpi_f2:
        st.metric("Avg Pendency Age", f"{filtered['age_years'].mean():.1f} yrs" if len(filtered) > 0 else "0.0 yrs")
    with kpi_f3:
        st.metric("Avg Priority", f"{filtered['priority_score'].mean():.1f}" if len(filtered) > 0 else "0.0")
    with kpi_f4:
        st.metric("Total Hearing Hours", f"{filtered['hearing_duration'].sum():.1f} hrs" if len(filtered) > 0 else "0.0 hrs")

    st.markdown("<div style='height:10px;'></div>", unsafe_allow_html=True)

    # Data Table
    display_cols = [c for c in filtered.columns if not c.endswith('_norm')]
    st.dataframe(filtered[display_cols], width="stretch", hide_index=True)

    # Action row: Export & Statistics
    col_d1, col_d2 = st.columns([1, 4])
    with col_d1:
        st.download_button(
            "⬇️ Export CSV",
            filtered[display_cols].to_csv(index=False).encode('utf-8'),
            "judicial_cases_sample.csv",
            "text/csv",
            width="stretch",
        )

    # Detailed Analytical Expander Sections
    t_tab1, t_tab2, t_tab3 = st.tabs(["📊 Descriptive Statistics", "📖 Feature Glossary", "🛡️ Data Quality Audit"])
    with t_tab1:
        stats = get_descriptive_stats(filtered)
        st.dataframe(stats.round(2), width="stretch")

    with t_tab2:
        st.markdown("#### Operational Definitions of Case Features")
        for feat, desc in FEATURE_DESCRIPTIONS.items():
            if feat in filtered.columns:
                st.markdown(f"- **`{feat}`**: {desc}")

    with t_tab3:
        report = validate_dataset(filtered)
        st.json(report)


# ══════════════════════════════════════════════════════════════
# PAGE 3: FUZZY SIMULATOR
# ══════════════════════════════════════════════════════════════

elif page == "🧠 AI Evaluator":
    st.markdown("""
        <div class="hero-banner">
            <h1 style="margin:0 0 6px 0; font-size:1.8rem;">🧠 AI Priority Evaluator</h1>
            <p style="margin:0; color:#94A3B8; font-size:0.92rem;">
                Explore how the Mamdani Fuzzy Inference System evaluates case variables through human-interpretable linguistic rules to generate an auditable urgency score.
            </p>
        </div>
    """, unsafe_allow_html=True)

    sim_tab1, sim_tab2 = st.tabs([
        "🎯 Interactive Case Calculator",
        "📋 Complete Judicial Rule Base"
    ])

    with sim_tab1:
        st.markdown("#### 1. Choose a Realistic Case Archetype or Adjust Sliders")
        st.caption("Click any preset to instantly load realistic case parameters, or customize the values manually:")

        p_col1, p_col2, p_col3, p_col4 = st.columns(4)
        with p_col1:
            if st.button("👵 Elderly Land Dispute", help="Backlogged 12 yrs, high vulnerability, moderate severity", width="stretch"):
                st.session_state.sim_age = 12.0
                st.session_state.sim_sev = 7
                st.session_state.sim_comp = 5
                st.session_state.sim_pub = 4
                st.session_state.sim_vuln = 9
                st.rerun()
        with p_col2:
            if st.button("🛡️ Child Custody Protection", help="Urgent family matter, critical vulnerability and severity", width="stretch"):
                st.session_state.sim_age = 2.5
                st.session_state.sim_sev = 9
                st.session_state.sim_comp = 4
                st.session_state.sim_pub = 6
                st.session_state.sim_vuln = 10
                st.rerun()
        with p_col3:
            if st.button("⚖️ Constitutional Challenge", help="High public interest, high legal complexity", width="stretch"):
                st.session_state.sim_age = 4.0
                st.session_state.sim_sev = 8
                st.session_state.sim_comp = 9
                st.session_state.sim_pub = 10
                st.session_state.sim_vuln = 5
                st.rerun()
        with p_col4:
            if st.button("🏢 Routine Corporate Breach", help="Recent filing, low vulnerability, commercial dispute", width="stretch"):
                st.session_state.sim_age = 0.8
                st.session_state.sim_sev = 3
                st.session_state.sim_comp = 7
                st.session_state.sim_pub = 2
                st.session_state.sim_vuln = 2
                st.rerun()

        st.markdown("<div style='height:12px;'></div>", unsafe_allow_html=True)

        col_in1, col_in2 = st.columns(2)
        with col_in1:
            age = st.slider(
                "Case Pendency Age (years)",
                0.1, 15.0, float(st.session_state.sim_age), 0.1,
                help="Duration the case has remained pending in the court docket"
            )
            severity = st.slider(
                "Legal Severity (1 - 10)",
                1, 10, int(st.session_state.sim_sev),
                help="1 = Minor infraction/petty suit, 10 = Severe rights violation / grave crime"
            )
            complexity = st.slider(
                "Legal & Evidentiary Complexity (1 - 10)",
                1, 10, int(st.session_state.sim_comp),
                help="Number of witnesses, forensic records, and legal precedents involved"
            )

        with col_in2:
            vulnerability = st.slider(
                "Litigant Vulnerability (1 - 10)",
                1, 10, int(st.session_state.sim_vuln),
                help="Special status: Senior citizen, minor child, indigent, or medically compromised litigant"
            )
            public_interest = st.slider(
                "Public Interest & Societal Impact (1 - 10)",
                1, 10, int(st.session_state.sim_pub),
                help="Impact on broader public governance, constitutional rights, or market stability"
            )

        # Update session state
        st.session_state.sim_age = age
        st.session_state.sim_sev = severity
        st.session_state.sim_comp = complexity
        st.session_state.sim_vuln = vulnerability
        st.session_state.sim_pub = public_interest

        # Normalize inputs for Fuzzy Inference
        def normalize_val(val, feat):
            lo, hi = FEATURE_RANGES[feat]
            return (val - lo) / (hi - lo) * 10.0

        input_vals = {
            "age_years": normalize_val(age, "age_years"),
            "severity": normalize_val(severity, "severity"),
            "complexity": normalize_val(complexity, "complexity"),
            "public_interest": normalize_val(public_interest, "public_interest"),
            "vulnerability": normalize_val(vulnerability, "vulnerability"),
        }

        # Compute with detailed breakdown
        details = compute_priority(input_vals, return_details=True)
        score = details['priority_score']
        tier_label, tier_color, tier_bg, tier_icon = get_priority_badge(score)

        st.markdown("---")

        # Visual Priority Meter Card
        res_col1, res_col2 = st.columns([1, 2])
        with res_col1:
            st.markdown(f"""
                <div class="priority-badge-box" style="background:{tier_bg}; border:2px solid {tier_color};">
                    <span style="font-size:32px;">{tier_icon}</span>
                    <h1 style="color:{tier_color} !important; font-size:3.0rem; margin:6px 0;">{score:.1f}</h1>
                    <div style="font-size:0.8rem; color:#CBD5E1; text-transform:uppercase; letter-spacing:1px; font-weight:700;">Computed Priority Score (0-100)</div>
                    <div style="margin-top:10px; display:inline-block; padding:4px 14px; border-radius:9999px; background:{tier_color}; color:#FFFFFF; font-weight:700; font-size:0.85rem;">
                        {tier_label}
                    </div>
                </div>
            """, unsafe_allow_html=True)

        with res_col2:
            st.markdown("#### 🔍 Explainable AI Decision Breakdown")

            # Dynamic plain-English reasoning
            drivers = []
            if vulnerability >= 7:
                drivers.append(f"extreme litigant vulnerability ({vulnerability}/10)")
            if severity >= 7:
                drivers.append(f"severe legal consequences ({severity}/10)")
            if age >= 8.0:
                drivers.append(f"protracted court pendency ({age:.1f} years backlog)")
            if public_interest >= 7:
                drivers.append(f"high public interest ({public_interest}/10)")

            if drivers:
                driver_text = " and ".join(drivers)
                explanation_str = f"This case is categorized as **{tier_label}** primarily due to {driver_text}. The Mamdani inference engine activated **{details['active_rules']} of {details['total_rules']} judicial rules**, centering defuzzified output at **{score:.1f}**."
            else:
                explanation_str = f"This case exhibits standard pendency and moderate attributes across all dimensions. With **{details['active_rules']} rules activated**, it is scheduled into the standard judicial queue with an urgency score of **{score:.1f}**."

            st.markdown(f"""
                <div class="clean-callout" style="border-left-color:{tier_color};">
                    {explanation_str}
                </div>
            """, unsafe_allow_html=True)

            q_m1, q_m2 = st.columns(2)
            with q_m1:
                st.metric("Active Rules Triggered", f"{details['active_rules']} / {details['total_rules']}")
            with q_m2:
                top_firing = max(details['rule_evaluations'], key=lambda r: r['firing_strength']) if details['rule_evaluations'] else None
                st.metric("Strongest Rule", f"{top_firing['rule_id'] if top_firing else 'None'} ({top_firing['firing_strength']:.2f})" if top_firing else "None")

        # Detailed Expander Breakdown
        with st.expander("🔬 Step-by-Step Inference Audit (Fuzzification & Active Rules)"):
            st.markdown("##### 1. Fuzzified Membership Degrees")
            for var, memberships in details['fuzzified_inputs'].items():
                st.markdown(f"**`{var}`** (Normalized Input: `{input_vals[var]:.2f}` / 10.0)")
                f_cols = st.columns(3)
                for i, (term, degree) in enumerate(memberships.items()):
                    with f_cols[i]:
                        st.progress(degree, text=f"{term}: {degree:.3f}")

            st.markdown("##### 2. Firing Rules & Strength")
            active_list = [r for r in details['rule_evaluations'] if r['firing_strength'] > 0]
            active_list = sorted(active_list, key=lambda x: x['firing_strength'], reverse=True)
            for rule in active_list:
                st.markdown(f"- **{rule['rule_id']}**: {rule['description']} ➔ Consequent: `{rule['consequent']}` (Strength: `{rule['firing_strength']:.4f}`)")

    with sim_tab2:
        st.markdown("### Full Auditable Rule Base (16 Expert Rules)")
        st.caption("Transparent IF-THEN rules designed according to judicial urgency jurisprudence")
        rules_df = pd.DataFrame(get_rules_table())
        st.dataframe(rules_df, width="stretch", hide_index=True)


# ══════════════════════════════════════════════════════════════
# PAGE 4: OPTIMIZATION LAB
# ══════════════════════════════════════════════════════════════

elif page == "🧬 AI Scheduler":
    st.markdown("""
        <div class="hero-banner">
            <h1 style="margin:0 0 6px 0; font-size:1.8rem;">🧬 AI Court Scheduler</h1>
            <p style="margin:0; color:#94A3B8; font-size:0.92rem;">
                Employ a <strong>Genetic Algorithm (GA)</strong> with Order Crossover (OX) to solve the combinatorial court scheduling problem — ensuring urgent cases are heard swiftly while adhering to daily courtroom capacity.
            </p>
        </div>
    """, unsafe_allow_html=True)

    # Explanation of the Optimization Problem
    st.markdown("""
        <div class="clean-callout">
            <strong>Why Genetic Algorithms for Court Schedules?</strong> Simply sorting cases by priority ignores courtroom session limits (e.g. 6 hours/day) and can leave high-complexity cases with huge delays. The GA explores thousands of conflict-free hearing sequences, seeking the global minimum of priority-weighted wait time and courtroom idle penalty.
        </div>
    """, unsafe_allow_html=True)

    # Presets for GA Execution
    st.markdown("#### 1. Select Optimization Preset")
    g_p1, g_p2, g_p3, g_p4 = st.columns(4)

    if 'ga_pop_size' not in st.session_state:
        st.session_state.ga_pop_size = 60
    if 'ga_gens' not in st.session_state:
        st.session_state.ga_gens = 40

    with g_p1:
        if st.button("⚡ Fast Demo (30 Gens)", help="Runs in ~1.5s. Great for quick testing", width="stretch"):
            st.session_state.ga_pop_size = 50
            st.session_state.ga_gens = 30
            st.rerun()
    with g_p2:
        if st.button("⚖️ Standard Run (80 Gens)", help="Balanced speed and convergence (~4s)", width="stretch"):
            st.session_state.ga_pop_size = 80
            st.session_state.ga_gens = 80
            st.rerun()
    with g_p3:
        if st.button("🔬 Deep Search (150 Gens)", help="Thorough exploration (~8s)", width="stretch"):
            st.session_state.ga_pop_size = 100
            st.session_state.ga_gens = 150
            st.rerun()
    with g_p4:
        st.markdown(f"<div style='text-align:center; padding:8px; color:#94A3B8; font-size:0.85rem;'>Config: Pop <strong>{st.session_state.ga_pop_size}</strong> | Gens <strong>{st.session_state.ga_gens}</strong></div>", unsafe_allow_html=True)

    with st.expander("⚙️ Advanced Hyperparameter Tuning"):
        col_ga1, col_ga2, col_ga3, col_ga4 = st.columns(4)
        with col_ga1:
            pop_size = st.number_input("Population Size", 20, 200, int(st.session_state.ga_pop_size), step=10)
        with col_ga2:
            gens = st.number_input("Generations", 10, 300, int(st.session_state.ga_gens), step=10)
        with col_ga3:
            mut_rate = st.slider("Mutation Rate (Swap)", 0.01, 0.50, GA_MUTATION_RATE, 0.01)
        with col_ga4:
            cx_rate = st.slider("Crossover Rate (OX)", 0.50, 1.00, GA_CROSSOVER_RATE, 0.05)
        ga_seed = st.number_input("GA Random Seed", value=RANDOM_SEED, step=1)

        st.session_state.ga_pop_size = pop_size
        st.session_state.ga_gens = gens

    # Run Optimization Button
    if st.button("🚀 Run Timetable Optimization", type="primary", width="stretch"):
        ages = df['age_years'].values
        durations = df['hearing_duration'].values
        target_days = df['target_day'].values
        case_types = df['case_type'].values

        progress_bar = st.progress(0, text="Initializing population of case permutations...")
        status_text = st.empty()

        def ga_progress(gen, best, avg):
            pct = min(gen / st.session_state.ga_gens, 1.0)
            progress_bar.progress(pct, text=f"Evaluating Generation {gen} of {st.session_state.ga_gens} | Best Objective: {best:,.0f}")

        start_time = time.time()
        results = compare_methods(
            ages, priorities, durations, target_days, case_types,
            seed=ga_seed if 'ga_seed' in locals() else RANDOM_SEED,
            ga_kwargs={
                "population_size": int(st.session_state.ga_pop_size),
                "generations": int(st.session_state.ga_gens),
                "mutation_rate": mut_rate if 'mut_rate' in locals() else GA_MUTATION_RATE,
                "crossover_rate": cx_rate if 'cx_rate' in locals() else GA_CROSSOVER_RATE,
            },
            progress_callback=ga_progress,
        )
        total_time = time.time() - start_time
        progress_bar.progress(1.0, text=f"Optimization Complete in {total_time:.2f} seconds!")
        st.session_state.results = results
        time.sleep(0.5)
        st.rerun()

    # Results Display Section (Persists Across Widget Interactions!)
    if st.session_state.results is not None:
        results = st.session_state.results
        ga_res = next((r for r in results if r['method'] == 'Genetic Algorithm'), None)
        fifo_res = next((r for r in results if 'FIFO' in r['method']), None)

        st.markdown("---")
        st.markdown("### 🏆 Optimization Results & Court Timetable")

        # Executive Summary Win Card
        if ga_res and fifo_res:
            improvement_pct = ((fifo_res['objective'] - ga_res['objective']) / fifo_res['objective']) * 100
            st.markdown(f"""
                <div class="clean-callout" style="border-left-color:#10B981; background:rgba(16, 185, 129, 0.08);">
                    <strong style="color:#10B981; font-size:1.05rem;">🎉 Success: Genetic Algorithm Improved Scheduling by {improvement_pct:.1f}% vs FIFO</strong><br>
                    By intelligently ordering {len(df)} cases across court sessions, the GA reduced priority-weighted waiting delays from <strong>{fifo_res['objective']:,.0f}</strong> down to <strong>{ga_res['objective']:,.0f}</strong>.
                </div>
            """, unsafe_allow_html=True)

        res_tab1, res_tab2, res_tab3, res_tab4 = st.tabs([
            "📅 Court Daily Docket Schedule",
            "📊 Baseline Method Comparison",
            "📈 GA Convergence Curve",
            "📋 Penalty Cost Breakdown"
        ])

        with res_tab1:
            st.markdown("#### Interactive Daily Court Calendar")
            st.caption(f"Optimized hearing sequence grouped by Court Day (Capacity: {DAILY_CAPACITY_HOURS} hours/day)")

            perm = ga_res['permutation']
            schedule_rows = []
            cum_time = 0.0

            for pos, idx in enumerate(perm):
                case_row = df.iloc[idx]
                case_dur = case_row['hearing_duration']
                start_h = cum_time % DAILY_CAPACITY_HOURS
                day_num = int(cum_time // DAILY_CAPACITY_HOURS) + 1
                end_h = start_h + case_dur
                cum_time += case_dur

                schedule_rows.append({
                    "Schedule Order": pos + 1,
                    "Court Day": f"Day {day_num}",
                    "Case ID": case_row['case_id'],
                    "Category": case_row['case_type'],
                    "Priority": f"{priorities[idx]:.1f}",
                    "Tier": get_priority_badge(priorities[idx])[0],
                    "Hearing Hours": round(case_dur, 1),
                    "Slot Time": f"{start_h:.1f}h - {start_h + case_dur:.1f}h",
                })

            sched_df = pd.DataFrame(schedule_rows)

            day_options = ["All Days (First 40 Cases)"] + sorted(sched_df['Court Day'].unique().tolist(), key=lambda x: int(x.replace("Day ", "")))
            selected_day = st.selectbox("Select Court Day to View:", options=day_options, index=0)

            if selected_day.startswith("All Days"):
                st.dataframe(sched_df.head(40), width="stretch", hide_index=True)
            else:
                day_filtered = sched_df[sched_df['Court Day'] == selected_day]
                st.dataframe(day_filtered, width="stretch", hide_index=True)

            st.download_button(
                "⬇️ Download Full Optimized Docket (CSV)",
                sched_df.to_csv(index=False).encode('utf-8'),
                "ga_optimized_court_schedule.csv",
                "text/csv",
            )

        with res_tab2:
            st.markdown("#### Performance Against Standard Court Scheduling Heuristics")
            _apply_style()
            fig_comp = plot_comparison_bar(results, save=False)
            st.pyplot(fig_comp)
            plt.close(fig_comp)

            # Clean Table
            table_rows = []
            sorted_res = sorted(results, key=lambda x: x['objective'])
            best_obj = sorted_res[0]['objective']

            for r in sorted_res:
                diff = r['objective'] - best_obj
                table_rows.append({
                    "Scheduling Method": r['method'],
                    "Composite Objective": f"{r['objective']:,.1f}",
                    "Difference vs Best": "0 (BEST)" if diff == 0 else f"+{diff:,.1f}",
                    "Avg Top-20% Urgency Position": f"{r.get('avg_top_priority_position', 0):.1f}",
                    "Runtime (s)": f"{r['runtime']:.4f}",
                })
            st.dataframe(pd.DataFrame(table_rows), width="stretch", hide_index=True)

        with res_tab3:
            st.markdown("#### Evolution of Objective Fitness Across Generations")
            if 'convergence_history' in ga_res:
                fig_conv = plot_convergence(
                    ga_res['convergence_history'],
                    ga_res.get('avg_fitness_history'),
                    save=False
                )
                st.pyplot(fig_conv)
                plt.close(fig_conv)

        with res_tab4:
            st.markdown("#### Objective Component Breakdown")
            st.caption("Lower value across each component signifies superior scheduling efficacy")
            detail_rows = []
            for r in results:
                comp = r.get('objective_components', {})
                detail_rows.append({
                    "Method": r['method'],
                    "Total Objective": f"{r['objective']:,.2f}",
                    "Priority-Weighted Completion": f"{comp.get('priority_weighted_completion', 0):,.2f}",
                    "Lateness Penalty": f"{comp.get('lateness_penalty', 0):,.2f}",
                    "Capacity Overflow Penalty": f"{comp.get('capacity_penalty', 0):,.2f}",
                    "Runtime (s)": f"{r['runtime']:.4f}",
                })
            st.dataframe(pd.DataFrame(detail_rows), width="stretch", hide_index=True)
    else:
        st.info("💡 Click **'Run Timetable Optimization'** above to generate the optimized court schedule.")


# ══════════════════════════════════════════════════════════════
