# ⚖️ CourtPrioritize AI — System Architecture, Research Framework & User Manual

> **Project:** Explainable Fuzzy-Genetic Optimization Framework for Judicial Case Scheduling  
> **Academic Unit:** SCOA FA-1 | CSE (AI & ML)  
> **Application:** Standalone Glassmorphic Decision-Support Web Suite  
> **Repository:** `judicial-case-prioritization/web_ui`

---

## 📑 Table of Contents
1. [Executive Summary](#1-executive-summary)
2. [Motivation](#2-motivation)
3. [Use Cases](#3-use-cases)
4. [Visual Design](#4-visual-design)

---

## 1. Executive Summary

**CourtPrioritize AI** is an explainable decision-support dashboard designed to solve the judicial case backlog and courtroom scheduling bottleneck. Combining **Soft Computing (Fuzzy Logic)** with **Evolutionary Optimization (Genetic Algorithms)**, the system:
1. **Audits & Triages Urgency:** Uses an interpretable 16-rule Mamdani Fuzzy Inference System to assign a fair, auditable priority score (0–100) to every pending legal matter.
2. **Generates Conflict-Free Courtroom Timetables:** Uses a permutation-based Genetic Algorithm with Order Crossover (OX) to schedule cases into courtrooms while strictly adhering to daily capacity limits (e.g. 6.0 hearing hours per courtroom).
3. **Presents a Modern, Tactile Web Dashboard:** Packaged in a glassmorphic interface with top tab navigation, case inspector modals, interactive sliders, and real-time comparative benchmarks.

---

## 2. Motivation

### The Problem: Global Court Gridlock & Inefficient Scheduling
Courts worldwide—most acutely in jurisdictions like India with over **4.4+ crore pending cases**—face severe structural backlogs:
- **Blind FIFO Scheduling:** Traditional court registries schedule cases primarily on First-In, First-Out (filing date). Critical matters (e.g. urgent bail, undertrial detentions, child custody) often languish behind commercial disputes.
- **Overloading & Adjournments:** Without intelligent timetable packing, courtrooms are either overloaded (causing end-of-day adjournments that waste litigant and attorney time) or underutilized.
- **The "Black-Box" AI Dilemma:** Modern deep neural networks cannot be deployed in courts because they cannot explain *why* a case was prioritized. Judges and citizens require constitutional transparency.

### The Solution: Transparent Soft Computing
CourtPrioritize AI was engineered to bridge this gap:
- **Why Fuzzy Logic?** Human legal concepts (like *"High Severity"*, *"Vulnerable Undertrial"*, *"Old Case"*) are fuzzy. Mamdani FIS models these concepts mathematically using explicit rules that judges can read and verify.
- **Why Genetic Algorithms?** Multi-courtroom scheduling is an NP-hard combinatorial bin-packing problem. Genetic Algorithms efficiently explore massive solution spaces ($200! \approx 7.8 \times 10^{374}$ permutations) to find optimal timetables in seconds.

---

## 3. Use Cases

### Use Case 1: Automated Registry Cause List Generation
Listing registrars and court clerks can generate a scientifically balanced daily hearing cause list that maximizes courtroom utilization while preventing judicial fatigue.

### Use Case 2: Interactive Case Urgency Triage (Fuzzy Simulator)
Judges can adjust parameters (Case Age, Severity, Vulnerability Index, Public Interest) to observe how linguistic rules interact and produce an auditable urgency rating.

### Use Case 3: Courtroom Load Leveling & Capacity Auditing
Bench chiefs can track courtroom allocations (Courtroom 1, Courtroom 2, Special Bench), ensure hearing hours stay within the 6.0 hr/day limit, and avoid adjournment roll-overs.

### Use Case 4: Academic & Policy Research Benchmarking
Researchers can compare Genetic Algorithms against traditional baselines (FIFO, Priority Sort, Shortest Hearing First) to quantify delay reductions and capacity utilization.

---

## 4. Visual Design

Built to match the user's reference dashboard, CourtPrioritize AI employs an aesthetic designed for focus and clarity:

### Visual Features:
- **Luminous Cyber & High-Court Palette:** Electric cyan (`#00f0ff`), royal justice purple (`#a855f7`), golden seal amber (`#ffb703`), and mint emerald (`#00f59b`).
- **Deep 28px Frosted Glass:** Surfaces use `backdrop-filter: blur(28px) saturate(190%)` over animated ambient floating gradient orbs (`floatOrb`).
- **Specular Rim Lighting:** Cards feature an inner bevel highlight (`inset 0 1px 1px rgba(255, 255, 255, 0.18)`) simulating chamfered glass reflecting light.
- **Clean & Proper Tab Structure:**
  - A persistent **Top Navigation Tab Bar** allows 1-click view switching.
  - Active tabs glow with high-saturation gradient pills.
  - Sub-tabs organize docket filters and rules lists without clutter.
