"""
Tests for the Fuzzy Inference Engine
=====================================
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

import pytest
import numpy as np
from src.fuzzy_engine import (
    triangular_mf, trapezoidal_mf, evaluate_mf,
    fuzzify_input, compute_priority, compute_all_priorities,
)
from src.config import FUZZY_INPUT_MFS, FUZZY_OUTPUT_RANGE


class TestTriangularMF:
    """Tests for triangular membership function."""

    def test_peak_value(self):
        """At peak b, membership should be 1.0."""
        assert triangular_mf(5.0, 2.0, 5.0, 8.0) == 1.0

    def test_left_foot(self):
        """At left foot a, membership should be 0.0."""
        assert triangular_mf(2.0, 2.0, 5.0, 8.0) == 0.0

    def test_right_foot(self):
        """At right foot c, membership should be 0.0."""
        assert triangular_mf(8.0, 2.0, 5.0, 8.0) == 0.0

    def test_midpoint_left(self):
        """Midpoint between a and b should be 0.5."""
        assert abs(triangular_mf(3.5, 2.0, 5.0, 8.0) - 0.5) < 0.01

    def test_midpoint_right(self):
        """Midpoint between b and c should be 0.5."""
        assert abs(triangular_mf(6.5, 2.0, 5.0, 8.0) - 0.5) < 0.01

    def test_outside_left(self):
        """Below left foot should be 0.0."""
        assert triangular_mf(0.0, 2.0, 5.0, 8.0) == 0.0

    def test_outside_right(self):
        """Above right foot should be 0.0."""
        assert triangular_mf(10.0, 2.0, 5.0, 8.0) == 0.0

    def test_returns_float(self):
        """Should always return a float."""
        result = triangular_mf(3.0, 2.0, 5.0, 8.0)
        assert isinstance(result, float)


class TestTrapezoidalMF:
    """Tests for trapezoidal membership function."""

    def test_plateau(self):
        """In the flat region [b,c], membership should be 1.0."""
        assert trapezoidal_mf(5.0, 2.0, 4.0, 6.0, 8.0) == 1.0
        assert trapezoidal_mf(4.0, 2.0, 4.0, 6.0, 8.0) == 1.0
        assert trapezoidal_mf(6.0, 2.0, 4.0, 6.0, 8.0) == 1.0

    def test_left_shoulder(self):
        """Left shoulder MF (a==b) should be 1.0 at left edge."""
        assert trapezoidal_mf(0.0, 0.0, 0.0, 2.0, 4.0) == 1.0

    def test_right_shoulder(self):
        """Right shoulder MF (c==d) should be 1.0 at right edge."""
        assert trapezoidal_mf(10.0, 6.0, 8.0, 10.0, 10.0) == 1.0

    def test_outside(self):
        """Outside the trapezoid should be 0.0."""
        assert trapezoidal_mf(0.0, 2.0, 4.0, 6.0, 8.0) == 0.0
        assert trapezoidal_mf(10.0, 2.0, 4.0, 6.0, 8.0) == 0.0


class TestFuzzifyInput:
    """Tests for fuzzification of inputs."""

    def test_low_value(self):
        """Low value should have high 'Low' membership."""
        result = fuzzify_input(1.0)
        assert result["Low"] > 0.5
        assert result["High"] == 0.0

    def test_high_value(self):
        """High value should have high 'High' membership."""
        result = fuzzify_input(9.0)
        assert result["High"] > 0.5
        assert result["Low"] == 0.0

    def test_medium_value(self):
        """Middle value should have 'Medium' membership."""
        result = fuzzify_input(5.0)
        assert result["Medium"] > 0.5

    def test_all_terms_present(self):
        """All linguistic terms should be in output."""
        result = fuzzify_input(5.0)
        for term in FUZZY_INPUT_MFS:
            assert term in result

    def test_memberships_non_negative(self):
        """All membership degrees must be >= 0."""
        for val in np.linspace(0, 10, 50):
            result = fuzzify_input(val)
            for degree in result.values():
                assert degree >= 0.0


class TestComputePriority:
    """Tests for the complete fuzzy inference pipeline."""

    def test_high_priority_case(self):
        """High age + high severity should produce high priority."""
        inputs = {
            "age_years": 9.0,
            "severity": 9.0,
            "complexity": 5.0,
            "public_interest": 7.0,
            "vulnerability": 8.0,
        }
        score = compute_priority(inputs)
        assert score > 60, f"Expected high priority, got {score}"

    def test_low_priority_case(self):
        """Low everything should produce low priority."""
        inputs = {
            "age_years": 1.0,
            "severity": 1.0,
            "complexity": 2.0,
            "public_interest": 1.0,
            "vulnerability": 1.0,
        }
        score = compute_priority(inputs)
        assert score < 40, f"Expected low priority, got {score}"

    def test_output_range(self):
        """Priority should be in [0, 100]."""
        for _ in range(20):
            inputs = {
                var: np.random.uniform(0, 10)
                for var in ["age_years", "severity", "complexity",
                            "public_interest", "vulnerability"]
            }
            score = compute_priority(inputs)
            assert FUZZY_OUTPUT_RANGE[0] <= score <= FUZZY_OUTPUT_RANGE[1], \
                f"Score {score} out of range"

    def test_return_details(self):
        """return_details=True should return a dict with expected keys."""
        inputs = {
            "age_years": 5.0, "severity": 5.0, "complexity": 5.0,
            "public_interest": 5.0, "vulnerability": 5.0,
        }
        result = compute_priority(inputs, return_details=True)
        assert isinstance(result, dict)
        assert "priority_score" in result
        assert "fuzzified_inputs" in result
        assert "rule_evaluations" in result
        assert "active_rules" in result

    def test_reproducibility(self):
        """Same inputs should always produce the same output."""
        inputs = {
            "age_years": 7.0, "severity": 6.0, "complexity": 4.0,
            "public_interest": 5.0, "vulnerability": 8.0,
        }
        score1 = compute_priority(inputs)
        score2 = compute_priority(inputs)
        assert score1 == score2


class TestComputeAllPriorities:
    """Tests for batch priority computation."""

    def test_correct_count(self):
        """Should return one score per row."""
        from src.data_generator import generate_cases
        from src.preprocessing import preprocess
        df = generate_cases(num_cases=20, seed=42)
        processed, _ = preprocess(df)
        scores = compute_all_priorities(processed)
        assert len(scores) == 20

    def test_all_valid_scores(self):
        """All scores should be in [0, 100]."""
        from src.data_generator import generate_cases
        from src.preprocessing import preprocess
        df = generate_cases(num_cases=20, seed=42)
        processed, _ = preprocess(df)
        scores = compute_all_priorities(processed)
        for s in scores:
            assert 0 <= s <= 100


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
