"""
Tests for the Objective Function
==================================
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

import pytest
import numpy as np
from src.objective import (
    compute_objective, validate_permutation,
    priority_weighted_completion, lateness_penalty, capacity_penalty,
)


class TestValidatePermutation:
    """Tests for permutation validation."""

    def test_valid_permutation(self):
        assert validate_permutation([0, 1, 2, 3, 4], 5) is True

    def test_valid_reversed(self):
        assert validate_permutation([4, 3, 2, 1, 0], 5) is True

    def test_wrong_length(self):
        assert validate_permutation([0, 1, 2], 5) is False

    def test_duplicate(self):
        assert validate_permutation([0, 1, 1, 3, 4], 5) is False

    def test_out_of_range(self):
        assert validate_permutation([0, 1, 2, 3, 5], 5) is False

    def test_empty(self):
        assert validate_permutation([], 0) is True


class TestPriorityWeightedCompletion:
    """Tests for priority-weighted completion time."""

    def test_basic_ordering(self):
        """Higher priority first should yield lower cost than reversed."""
        priorities = np.array([10.0, 5.0, 1.0])
        durations = np.array([1.0, 1.0, 1.0])

        perm_good = [0, 1, 2]  # High priority first
        perm_bad = [2, 1, 0]   # Low priority first

        cost_good = priority_weighted_completion(perm_good, priorities, durations)
        cost_bad = priority_weighted_completion(perm_bad, priorities, durations)

        assert cost_good < cost_bad

    def test_zero_priorities(self):
        """Zero priorities should give zero cost."""
        priorities = np.array([0.0, 0.0, 0.0])
        durations = np.array([1.0, 2.0, 3.0])
        cost = priority_weighted_completion([0, 1, 2], priorities, durations)
        assert cost == 0.0


class TestLatenessPenalty:
    """Tests for lateness penalty."""

    def test_no_lateness(self):
        """All cases within target should have zero penalty."""
        durations = np.array([1.0, 1.0])
        target_days = np.array([100.0, 100.0])
        penalty = lateness_penalty([0, 1], durations, target_days)
        assert penalty == 0.0

    def test_with_lateness(self):
        """Late cases should incur positive penalty."""
        durations = np.array([40.0, 40.0])  # 40h each = 5 days each
        target_days = np.array([3.0, 3.0])  # Both due in 3 days
        penalty = lateness_penalty([0, 1], durations, target_days)
        assert penalty > 0


class TestComputeObjective:
    """Tests for composite objective function."""

    def test_returns_float(self):
        """Should return a numeric value."""
        priorities = np.array([5.0, 3.0, 8.0])
        durations = np.array([1.0, 2.0, 1.5])
        target_days = np.array([10.0, 20.0, 15.0])

        result = compute_objective([0, 1, 2], priorities, durations, target_days)
        assert isinstance(result, (int, float))

    def test_returns_components(self):
        """return_components=True should return a dict."""
        priorities = np.array([5.0, 3.0, 8.0])
        durations = np.array([1.0, 2.0, 1.5])
        target_days = np.array([10.0, 20.0, 15.0])

        result = compute_objective(
            [0, 1, 2], priorities, durations, target_days,
            return_components=True
        )
        assert isinstance(result, dict)
        assert "total" in result
        assert "priority_weighted_completion" in result
        assert "lateness_penalty" in result

    def test_invalid_permutation_raises(self):
        """Invalid permutation should raise AssertionError."""
        priorities = np.array([5.0, 3.0])
        durations = np.array([1.0, 2.0])
        target_days = np.array([10.0, 20.0])

        with pytest.raises(AssertionError):
            compute_objective([0, 0], priorities, durations, target_days)

    def test_consistency(self):
        """Same inputs should always produce same output."""
        priorities = np.array([5.0, 3.0, 8.0, 1.0])
        durations = np.array([1.0, 2.0, 1.5, 3.0])
        target_days = np.array([10.0, 20.0, 15.0, 25.0])

        obj1 = compute_objective([0, 1, 2, 3], priorities, durations, target_days)
        obj2 = compute_objective([0, 1, 2, 3], priorities, durations, target_days)
        assert obj1 == obj2


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
