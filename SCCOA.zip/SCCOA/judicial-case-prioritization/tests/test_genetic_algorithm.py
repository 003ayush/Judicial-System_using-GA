"""
Tests for the Genetic Algorithm
=================================
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

import pytest
import numpy as np
from src.genetic_algorithm import GeneticAlgorithm
from src.objective import validate_permutation


def simple_fitness(perm):
    """Simple fitness: sum of (position * value). Lower = better when sorted ascending."""
    return sum(pos * val for pos, val in enumerate(perm))


class TestGABasics:
    """Basic GA functionality tests."""

    def test_returns_valid_permutation(self):
        """GA should return a valid permutation."""
        ga = GeneticAlgorithm(
            fitness_func=simple_fitness,
            n_items=10,
            population_size=20,
            generations=10,
            seed=42,
        )
        result = ga.run()
        assert validate_permutation(result.best_permutation, 10)

    def test_all_cases_appear_once(self):
        """Every case index must appear exactly once."""
        ga = GeneticAlgorithm(
            fitness_func=simple_fitness,
            n_items=20,
            population_size=20,
            generations=10,
            seed=42,
        )
        result = ga.run()
        perm = result.best_permutation
        assert len(perm) == 20
        assert len(set(perm)) == 20
        assert set(perm) == set(range(20))

    def test_fitness_improves(self):
        """Best fitness should improve or stay the same over generations."""
        ga = GeneticAlgorithm(
            fitness_func=simple_fitness,
            n_items=15,
            population_size=30,
            generations=50,
            seed=42,
        )
        result = ga.run()
        history = result.convergence_history
        # Convergence history should be non-increasing (since we track best)
        for i in range(1, len(history)):
            assert history[i] <= history[i - 1] + 1e-10, \
                f"Fitness increased at gen {i}: {history[i-1]} -> {history[i]}"

    def test_reproducibility(self):
        """Same seed should produce the same result."""
        def run_ga():
            ga = GeneticAlgorithm(
                fitness_func=simple_fitness,
                n_items=10,
                population_size=20,
                generations=20,
                seed=42,
            )
            return ga.run()

        r1 = run_ga()
        r2 = run_ga()
        assert r1.best_permutation == r2.best_permutation
        assert r1.best_fitness == r2.best_fitness

    def test_convergence_history_length(self):
        """Convergence history should have generations+1 entries."""
        gens = 30
        ga = GeneticAlgorithm(
            fitness_func=simple_fitness,
            n_items=10,
            population_size=20,
            generations=gens,
            seed=42,
        )
        result = ga.run()
        assert len(result.convergence_history) == gens + 1

    def test_runtime_positive(self):
        """Runtime should be a non-negative number."""
        ga = GeneticAlgorithm(
            fitness_func=simple_fitness,
            n_items=10,
            population_size=10,
            generations=5,
            seed=42,
        )
        result = ga.run()
        assert result.runtime_seconds >= 0


class TestGAWithRealObjective:
    """Test GA with the actual scheduling objective."""

    def test_ga_with_scheduling_objective(self):
        """GA should produce a valid schedule with real objective."""
        from src.data_generator import generate_cases
        from src.preprocessing import preprocess
        from src.fuzzy_engine import compute_all_priorities
        from src.objective import compute_objective

        df = generate_cases(num_cases=30, seed=42)
        processed, _ = preprocess(df)
        scores = compute_all_priorities(processed)
        processed['priority_score'] = scores

        priorities = np.array(scores)
        durations = processed['hearing_duration'].values
        target_days = processed['target_day'].values

        def fitness(perm):
            return compute_objective(perm, priorities, durations, target_days)

        ga = GeneticAlgorithm(
            fitness_func=fitness,
            n_items=30,
            population_size=30,
            generations=30,
            seed=42,
        )
        result = ga.run()

        assert validate_permutation(result.best_permutation, 30)
        assert result.best_fitness > 0
        assert result.best_fitness == min(result.convergence_history)

    def test_ga_beats_random(self):
        """GA should produce a better objective than random ordering (usually)."""
        n = 30
        priorities = np.random.RandomState(42).uniform(10, 90, n)
        durations = np.random.RandomState(42).uniform(0.5, 5.0, n)
        target_days = np.random.RandomState(42).uniform(5, 40, n)

        def fitness(perm):
            from src.objective import compute_objective
            return compute_objective(perm, priorities, durations, target_days)

        # Random baseline
        random_perm = list(range(n))
        np.random.RandomState(99).shuffle(random_perm)
        random_obj = fitness(random_perm)

        # GA
        ga = GeneticAlgorithm(
            fitness_func=fitness,
            n_items=n,
            population_size=40,
            generations=50,
            seed=42,
        )
        result = ga.run()

        assert result.best_fitness <= random_obj, \
            f"GA ({result.best_fitness}) did not beat random ({random_obj})"


class TestGAOperators:
    """Test individual GA operators."""

    def test_order_crossover_validity(self):
        """OX should always produce valid permutations."""
        ga = GeneticAlgorithm(
            fitness_func=simple_fitness,
            n_items=20,
            seed=42,
        )
        parent1 = list(range(20))
        parent2 = list(range(19, -1, -1))

        for _ in range(50):
            child1, child2 = ga._order_crossover(parent1, parent2)
            assert validate_permutation(child1, 20), f"Invalid child1: {child1}"
            assert validate_permutation(child2, 20), f"Invalid child2: {child2}"

    def test_swap_mutation_validity(self):
        """Swap mutation should always produce valid permutations."""
        ga = GeneticAlgorithm(
            fitness_func=simple_fitness,
            n_items=20,
            seed=42,
        )
        individual = list(range(20))

        for _ in range(50):
            mutated = ga._swap_mutation(individual)
            assert validate_permutation(mutated, 20), f"Invalid mutated: {mutated}"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
