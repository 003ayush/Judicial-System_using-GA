@echo off
echo ===================================================================
echo e-Courts Judicial Case Prioritization & Timetable Scheduling Portal
echo CourtPrioritize AI | Decision Support Prototype
echo ===================================================================
echo Opening web portal in default browser...
start http://localhost:8000
python -m http.server 8000 --directory "%~dp0web_ui"
pause
