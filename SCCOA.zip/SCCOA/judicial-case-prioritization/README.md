# Fuzzy-Hybrid Judicial Case Prioritization System

## An Explainable Fuzzy-Genetic Optimization Framework for Judicial Case Scheduling Under Backlog Constraints

[![Python 3.10+](https://img.shields.io/badge/python-3.10+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

> **ACADEMIC RESEARCH PROTOTYPE** — SCOA FA-1 (AY 2026-27) | CSE (AI & ML)
> 
> This is a decision-support prototype using **synthetic data only**. It does NOT make real judicial decisions.

---

## Overview

This project implements a **Fuzzy Logic + Genetic Algorithm hybrid** system for optimizing judicial case scheduling. It demonstrates how soft computing techniques can be applied to the problem of court case backlog management.

### Key Features

- **Synthetic Dataset Generator**: Reproducible generation of 200+ judicial case records
- **Custom Fuzzy Inference Engine**: Transparent Mamdani-style FIS with 16 interpretable rules
- **Genetic Algorithm Optimizer**: Permutation-based GA with order crossover and swap mutation
- **Baseline Comparisons**: FIFO, Priority Sort, Random, and Shortest Hearing First
- **Interactive Dashboard**: Professional Streamlit UI with 6 pages
- **Research-Quality Evaluation**: Repeated trials, sensitivity analysis, statistical summaries

---

## Quick Start

### 1. Install Dependencies

```bash
cd judicial-case-prioritization
python -m pip install -r requirements.txt
```

### 2. Run the Experiment

```bash
python experiments/run_experiment.py
```

### 3. Launch the Dashboard

```bash
streamlit run app.py
```

### 4. Run Tests

```bash
python -m pytest tests/ -v
```

---

## Project Structure

```
judicial-case-prioritization/
├── app.py                          # Streamlit dashboard (6 pages)
├── requirements.txt                # Python dependencies
├── README.md                       # This file
├── .gitignore
│
├── src/                            # Core modules
│   ├── __init__.py
│   ├── config.py                   # All configurable parameters
│   ├── data_generator.py           # Synthetic dataset generation
│   ├── preprocessing.py            # Data validation & normalization
│   ├── fuzzy_engine.py             # Custom fuzzy inference engine
│   ├── fuzzy_rules.py              # 16 explicit fuzzy rules
│   ├── objective.py                # Composite scheduling objective
│   ├── genetic_algorithm.py        # Permutation-based GA
│   ├── baselines.py                # FIFO, Priority Sort, Random, SHF
│   ├── evaluation.py               # Comparison & statistical analysis
│   ├── visualization.py            # Research-quality charts
│   └── utils.py                    # Utility functions
│
├── experiments/                    # Experiment scripts
│   ├── run_experiment.py           # Main experiment pipeline
│   ├── run_sensitivity.py          # Sensitivity analysis
│   └── run_repeated_trials.py      # Multi-seed statistical evaluation
│
├── data/                           # Datasets
│   ├── raw/
│   ├── processed/
│   └── synthetic_cases.csv
│
├── results/                        # Experiment outputs
│   ├── figures/                    # Generated charts (PNG)
│   └── tables/                     # Result tables (CSV)
│
├── docs/                           # Documentation
│   ├── research_article.md         # IEEE-style research article
│   ├── methodology.md
│   ├── literature_review.md
│   ├── presentation_outline.md     # HOD presentation + speaker notes
│   └── references.md
│
└── tests/                          # Unit tests (48 tests)
    ├── test_fuzzy_engine.py
    ├── test_objective.py
    └── test_genetic_algorithm.py
```

---

## Methodology

### 1. Synthetic Dataset
- 200 cases across 5 types (Civil, Criminal, Family, Commercial, Constitutional)
- Features: age, severity, complexity, public interest, vulnerability, hearing duration, etc.
- Reproducible via fixed random seed

### 2. Fuzzy Inference System
- **Inputs**: Case age, severity, complexity, public interest, vulnerability (normalized 0-10)
- **Output**: Priority score (0-100)
- **Membership Functions**: Triangular and trapezoidal
- **Rules**: 16 explicit IF-THEN rules
- **Defuzzification**: Centroid method

### 3. Genetic Algorithm
- **Representation**: Permutation of case indices
- **Selection**: Tournament (k=5)
- **Crossover**: Order Crossover (OX)
- **Mutation**: Swap mutation
- **Elitism**: Top 2 preserved
- **Default**: 80 population, 150 generations

### 4. Objective Function
```
f = w1·PriorityWeightedCompletion + w2·LatenessPenalty + w3·CapacityPenalty + w4·ConcentrationPenalty
```
Lower value = better schedule.

---

## Results Summary

| Method | Objective | Improvement |
|--------|-----------|-------------|
| Genetic Algorithm | 107,328 | **Best** |
| Shortest Hearing First | 149,200 | — |
| Priority Sort | 177,072 | — |
| FIFO (Oldest First) | 218,963 | — |
| Random | 237,136 | — |

GA achieves ~28% improvement over the next best baseline on the composite objective.

---

## Team Responsibilities

| Member | Role | Components |
|--------|------|------------|
| Member 1 [Name/Roll] | Data & Literature | Dataset generation, preprocessing, literature survey |
| Member 2 [Name/Roll] | Fuzzy Logic | Membership functions, rules, mathematical explanation |
| Member 3 [Name/Roll] | Optimization | GA, objective function, experimental evaluation |
| Member 4 [Name/Roll] | Presentation | Dashboard, visualizations, research article |

---

## Ethical Statement

This system is an **academic research prototype** that:
- Uses **synthetic data only**
- Does **NOT** decide guilt, predict verdicts, or recommend sentences
- Does **NOT** replace judicial decision-making
- Must **NOT** be used as an operational court management product

All results are based on synthetic data and must not be interpreted as evidence of actual judicial system improvement.

---

## Course Information

- **Course**: Soft Computing and Optimization Algorithms (SCOA)
- **Assessment**: Formative Assessment-1
- **Department**: CSE (AI & ML)
- **Academic Year**: 2026-27
- **Faculty**: Dr. Anuradha Thakare
- **Institution**: Pimpri Chinchwad College of Engineering (PCCoE)
