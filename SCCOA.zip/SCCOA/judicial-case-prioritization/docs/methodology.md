# Methodology — Detailed Technical Documentation

## 1. System Overview

The Fuzzy-Hybrid Judicial Case Prioritization System is a decision-support prototype that combines Fuzzy Logic with a Genetic Algorithm to optimize judicial case scheduling. The system operates as a six-stage pipeline.

## 2. Data Generation

### 2.1 Synthetic Dataset Design

The dataset generator creates N synthetic judicial cases (default: 200) with the following features:

| Feature | Type | Range | Distribution |
|---------|------|-------|-------------|
| case_id | String | CASE-0001 to CASE-NNNN | Sequential |
| case_type | Categorical | Civil/Criminal/Family/Commercial/Constitutional | Weighted: 30/25/20/15/10% |
| age_years | Float | 0.1 – 15.0 | Exponential (scale=3.0) |
| severity | Integer | 1 – 10 | Normal, varies by type |
| complexity | Integer | 1 – 10 | Normal, varies by type |
| public_interest | Integer | 1 – 10 | Normal, varies by type |
| vulnerability | Integer | 1 – 10 | Correlated with severity |
| hearing_duration | Float | 0.5 – 8.0 | Correlated with complexity |
| target_day | Integer | 1 – 60 | Inversely correlated with severity |
| pending_documents | Integer | 0 – 20 | Poisson, correlated with complexity |
| historical_adjournments | Integer | 0 – 30 | Poisson, correlated with age |

### 2.2 Design Assumptions

- Case type distribution approximates real-world proportions (Civil cases most common)
- Feature correlations reflect logical relationships (e.g., criminal cases tend more severe)
- All data is synthetic — no real court records are used

## 3. Preprocessing

### 3.1 Data Quality Checks
- Missing value detection
- Duplicate case ID detection
- Range validation for all numeric features

### 3.2 Normalization
Min-max normalization maps each feature to the [0, 10] range for fuzzy inference:

$$x_{norm} = \frac{x - x_{min}}{x_{max} - x_{min}} \times 10$$

## 4. Fuzzy Inference System

### 4.1 Architecture
- **Type**: Mamdani-style fuzzy inference
- **Implementation**: Custom (no external fuzzy library)
- **Inputs**: 5 variables (age, severity, complexity, public_interest, vulnerability)
- **Output**: Priority score (0-100)

### 4.2 Membership Functions
- **Input MFs**: 3 terms per variable (Low, Medium, High)
  - Low: Trapezoidal (0, 0, 2, 4)
  - Medium: Triangular (2, 5, 8)
  - High: Trapezoidal (6, 8, 10, 10)

- **Output MFs**: 5 terms (Very_Low to Very_High)

### 4.3 Rule Evaluation Pipeline
1. **Fuzzification**: Map each crisp input to membership degrees
2. **Rule Firing**: Evaluate 16 rules using min (AND) conjunction
3. **Implication**: Clip consequent MFs at firing strength (Mamdani)
4. **Aggregation**: Max-aggregation of all clipped consequents
5. **Defuzzification**: Centroid method

## 5. Scheduling Optimization

### 5.1 Objective Function
Composite objective with four terms, all configurable:
- Priority-weighted completion time (w1=1.0)
- Lateness penalty squared (w2=2.0)
- Capacity utilization penalty (w3=0.5)
- Category concentration penalty (w4=0.3)

### 5.2 Genetic Algorithm
- Population of permutations
- Tournament selection (k=5)
- Order Crossover (OX) — always produces valid permutations
- Swap mutation — always preserves validity
- Elitism (top 2)

## 6. Evaluation

### 6.1 Baselines
- FIFO (oldest case first)
- Priority Sort (highest fuzzy priority first)
- Random
- Shortest Hearing First

### 6.2 Statistical Analysis
- Repeated trials with multiple random seeds
- Mean, standard deviation, min, max for all metrics
- Sensitivity analysis for GA parameters
