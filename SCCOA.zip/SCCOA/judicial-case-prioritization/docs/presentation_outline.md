# HOD Presentation Outline — Judicial Case Prioritization System

## Slide-by-Slide Outline with Speaker Notes

---

### Slide 1: Title Slide

**Title**: An Explainable Fuzzy-Genetic Optimization Framework for Judicial Case Scheduling Under Backlog Constraints

**Subtitle**: SCOA FA-1 | AY 2026-27 | CSE (AI & ML)

**Team Members**:
- Member 1: [Name / Roll Number]
- Member 2: [Name / Roll Number]
- Member 3: [Name / Roll Number]
- Member 4: [Name / Roll Number]

**Faculty**: Dr. Anuradha Thakare

**Speaker Notes**: "Good morning. We are presenting our SCOA FA-1 project on Fuzzy-Genetic optimization for judicial case scheduling. This is an academic research prototype that demonstrates how soft computing techniques can address the court backlog problem."

---

### Slide 2: Problem Statement

**Content**:
- Courts face millions of pending cases
- Limited hearing time and administrative resources
- Current scheduling: mostly FIFO or manual prioritization
- Cases have multiple urgency dimensions (age, severity, vulnerability, public interest)
- No single simple ordering optimally addresses all concerns

**Speaker Notes**: "The problem we're addressing is the growing judicial case backlog. Courts handle diverse case types with varying urgency, but traditional scheduling methods like FIFO only consider one factor. We propose a soft computing approach that considers multiple dimensions simultaneously."

---

### Slide 3: Motivation & Real-World Context

**Content**:
- India's NJDG reports millions of pending cases across courts
- Delays cause denied justice, especially for vulnerable parties
- Multi-criteria nature makes manual optimization infeasible
- Need: transparent, interpretable priority system + intelligent scheduling

**Speaker Notes**: "According to the National Judicial Data Grid, case backlogs are a significant challenge in the Indian judiciary. Our motivation is to demonstrate how AI and soft computing can assist—not replace—judicial decision-making through transparent prioritization."

---

### Slide 4: Objectives

**Content**:
1. Generate a reproducible synthetic judicial case dataset
2. Develop an interpretable fuzzy priority scoring system
3. Implement a Genetic Algorithm for schedule optimization
4. Compare with baseline scheduling methods
5. Provide statistical evaluation and sensitivity analysis
6. Discuss ethical implications and limitations

**Speaker Notes**: "Our objectives cover the full pipeline from data generation through optimization and evaluation. Importantly, we also address ethical considerations and transparency."

---

### Slide 5: Existing Approaches & Research Gap

**Content**:
| Approach | Limitation |
|----------|-----------|
| FIFO scheduling | Ignores case urgency |
| Manual prioritization | Subjective, not scalable |
| Rule-based expert systems | Rigid, non-adaptive |
| ML prediction models | Black-box, not transparent |

**Research Gap**: No hybrid fuzzy-GA approach with explicit transparency and ethical safeguards for judicial scheduling.

**Speaker Notes**: "Existing approaches either ignore priority entirely or use black-box models. Our contribution is a transparent hybrid approach where every priority rule is human-readable and every scheduling decision is auditable."

---

### Slide 6: Proposed Methodology

**Content**: Architecture diagram showing the 6-stage pipeline:
1. Synthetic Data Generation → 2. Preprocessing → 3. Fuzzy Inference → 4. GA Optimization → 5. Evaluation → 6. Visualization

**Speaker Notes**: "Our methodology follows a six-stage pipeline. First we generate synthetic data, then preprocess and normalize it, compute fuzzy priorities, optimize the schedule with a GA, compare against baselines, and visualize the results."

---

### Slide 7: System Architecture

**Content**: Detailed flow diagram with modules:
- `data_generator.py` → `preprocessing.py` → `fuzzy_engine.py` → `genetic_algorithm.py`
- `objective.py` connects to both GA and baselines
- Results flow to `visualization.py` and `app.py` (dashboard)

**Speaker Notes**: "The implementation is modular Python code. Each component is a separate module that can be tested independently. The system is built with Streamlit for the interactive dashboard."

---

### Slide 8: Fuzzy Inference System

**Content**:
- 5 input variables, 1 output (priority 0-100)
- Triangular and trapezoidal membership functions
- 16 IF-THEN rules
- Mamdani-style inference with centroid defuzzification
- Example: IF age IS High AND severity IS High THEN priority IS Very High
- Show MF plots

**Speaker Notes**: "Our fuzzy system takes five normalized inputs and produces a priority score from 0 to 100. We use 16 explicit rules designed to capture common-sense judicial prioritization logic. For example, old cases with high severity get very high priority. Importantly, complexity alone does not deprioritize a case."

---

### Slide 9: Genetic Algorithm

**Content**:
- Representation: Permutation of case indices
- Population: 80, Generations: 150
- Tournament selection (k=5)
- Order Crossover (OX) — preserves permutation validity
- Swap mutation
- Elitism: top 2 preserved
- Show convergence graph

**Speaker Notes**: "The GA uses permutation encoding where each chromosome represents a scheduling order. We use Order Crossover which always produces valid permutations—this is critical since invalid schedules where cases are missing or duplicated would be meaningless. The convergence graph shows steady improvement over 150 generations."

---

### Slide 10: Dataset & Preprocessing

**Content**:
- 200 synthetic cases, 5 types (Civil, Criminal, Family, Commercial, Constitutional)
- Features: age, severity, complexity, public interest, vulnerability, hearing duration, etc.
- Fixed random seed (42) for reproducibility
- Min-max normalization to [0, 10] for fuzzy inputs
- Data quality: no missing values, no duplicates, all ranges valid

**Speaker Notes**: "We generate 200 synthetic cases with realistic feature correlations. For example, criminal cases tend to have higher severity, and constitutional cases tend to have higher complexity and public interest. The data is fully synthetic and clearly labeled as such."

---

### Slide 11: Experimental Results

**Content**:
| Method | Objective | Improvement |
|--------|-----------|-------------|
| **GA** | **107,328** | **Best** |
| SHF | 149,200 | — |
| Priority Sort | 177,072 | — |
| FIFO | 218,963 | — |
| Random | 237,136 | — |

- GA achieves 28.1% improvement over next best baseline
- Show comparison bar chart

**Speaker Notes**: "The GA achieves the lowest composite objective value, representing a 28% improvement over the Shortest Hearing First baseline and 55% over random scheduling. This improvement comes from the GA's ability to simultaneously optimize multiple competing objectives."

---

### Slide 12: Dashboard Demonstration

**Content**: Screenshots of the 6 dashboard pages:
1. Dashboard overview with metrics
2. Dataset explorer with filtering
3. Fuzzy simulator with interactive sliders
4. Optimization lab with GA configuration
5. Results with statistical analysis
6. Methodology documentation

**Speaker Notes**: "We built a professional Streamlit dashboard with six pages. Let me walk through the key features: the fuzzy simulator lets you explore how different case profiles are scored, and the optimization lab lets you configure GA parameters and run experiments interactively."

---

### Slide 13: Limitations & Ethical Safeguards

**Content**:
- **Synthetic data only** — no real court records used
- **Subjective rules** — designed for academic demonstration
- **Does NOT**: decide guilt, predict verdicts, replace judges
- **Bias risk**: "vulnerability" and "public interest" are inherently subjective proxies
- **Required for real deployment**: legal expert validation, bias audits, human oversight, appeal mechanism

**Speaker Notes**: "We want to be very clear about limitations. This is a prototype using synthetic data. The fuzzy rules are subjective and would need extensive stakeholder validation for any real-world application. The system must not be used to make actual judicial decisions."

---

### Slide 14: Conclusion & Future Scope

**Content**:
**Conclusions**:
- Hybrid Fuzzy-GA approach successfully demonstrates multi-criteria scheduling optimization
- Transparent, interpretable rules with 28% objective improvement
- Complete working prototype with dashboard, tests, and documentation

**Future Scope**:
- Real-world validation with anonymized data
- Multi-objective Pareto optimization (NSGA-II)
- Dynamic scheduling with case arrivals
- Judge-case matching and workload balancing

**Speaker Notes**: "In conclusion, our hybrid approach successfully demonstrates how soft computing can address judicial scheduling. The GA provides measurable improvement while the fuzzy system maintains interpretability. Future work would involve real-world validation and more sophisticated optimization techniques."

---

### Slide 15: Thank You & Q&A

**Content**: Thank you. Questions?

**Team Contact**: [Names and Roll Numbers]

**Speaker Notes**: "Thank you for your attention. We're happy to answer any questions about our methodology, implementation, or results."

---

## Possible Viva Questions and Answers

### Q1: Why did you choose Fuzzy Logic over other soft computing techniques for priority scoring?
**A**: Fuzzy logic is ideal for this problem because judicial priority involves inherently imprecise concepts like "high severity" or "very old case." Unlike crisp thresholds, fuzzy membership functions can capture the gradual transition between categories. Additionally, fuzzy IF-THEN rules are human-readable, making the system transparent and auditable—a critical requirement for any judicial decision support system.

### Q2: Why Genetic Algorithm instead of PSO or other metaheuristics?
**A**: GAs are well-suited for permutation-based optimization problems like scheduling because we can use specialized operators (Order Crossover, Swap Mutation) that always produce valid permutations. PSO naturally works in continuous spaces and would require additional adaptation for discrete permutation problems. GA also has a strong theoretical foundation for combinatorial optimization.

### Q3: How do you ensure the GA always produces a valid schedule?
**A**: We use permutation-preserving operators throughout. Order Crossover (OX) works by copying a substring from one parent and filling remaining positions from the other parent in order, which mathematically guarantees no duplicates or missing items. Swap mutation simply exchanges two positions, which also preserves permutation validity. We additionally validate every solution with an assertion check.

### Q4: What is the time complexity of your GA?
**A**: The GA's time complexity is O(G × P × N × F), where G is the number of generations, P is the population size, N is the number of cases, and F is the cost of evaluating the fitness function. With our default parameters (G=150, P=80, N=200), the algorithm completes in approximately 10 seconds on a standard laptop.

### Q5: Why synthetic data instead of real court data?
**A**: We use synthetic data for several important reasons: (1) Real court data may contain sensitive personal information requiring privacy protections, (2) We can control and document all feature distributions and correlations, (3) Results are fully reproducible with a fixed random seed, (4) This is an academic prototype—using real data might imply the system is ready for deployment, which it is not.

### Q6: How did you design the fuzzy rules?
**A**: The rules are designed based on common-sense judicial prioritization principles: old cases with high severity need urgent attention, vulnerable parties should not wait, and high public interest demands timely resolution. Importantly, we ensured that complexity alone does not deprioritize a case—a complex case with vulnerable parties still receives high priority. In a real system, these rules would be refined through consultation with judges and legal experts.

### Q7: What are the membership function types and why did you choose them?
**A**: We use triangular MFs for the middle terms (Medium, Low, High output) and trapezoidal MFs for the extreme terms (Low/High input, Very Low/Very High output). Trapezoidal MFs at the boundaries create "shoulder" functions that plateau at the extremes, which is appropriate because very low or very high values should all be treated similarly—there's no meaningful distinction between severity 9 and severity 10, for instance.

### Q8: What is the defuzzification method and why?
**A**: We use centroid (center of gravity) defuzzification, which computes the weighted average of the aggregated fuzzy output set. This is the most common defuzzification method because it produces smooth, continuous output values and considers the entire shape of the output fuzzy set, not just its maximum.

### Q9: How would you handle bias in a real system?
**A**: Bias mitigation would require: (1) Careful definition of features like "vulnerability" and "public interest" with input from diverse stakeholders, (2) Regular audits of scheduling outcomes across case categories to detect systematic disparities, (3) Transparent rule documentation so all stakeholders can review and challenge the logic, (4) Human oversight—a judge should always have the final say, (5) An appeal mechanism for cases that are deprioritized.

### Q10: What course outcomes does this project address?
**A**: This project addresses all three course outcomes: CO1 (Identify soft computing techniques and their roles in problem solving) — we identify and justify the selection of fuzzy logic and GA. CO2 (Create fuzzy datasets and apply fuzzy inference systems) — we create a fuzzy dataset and implement a complete Mamdani FIS. CO3 (Analyze different strategies for evolutionary computing) — we implement a GA and compare it with multiple baseline strategies.

### Q11: Explain the objective function mathematically.
**A**: The objective function is a weighted sum: f(π) = w₁·C_pwc + w₂·L + w₃·P_cap + w₄·P_conc, where π is the scheduling permutation. C_pwc is the priority-weighted completion time (penalizes scheduling high-priority cases late), L is the squared lateness penalty (penalizes missing target days), P_cap is the capacity penalty (penalizes day-to-day capacity waste), and P_conc is the concentration penalty (encourages mixed case types). Lower values indicate better schedules.

### Q12: What would you change if you had more time?
**A**: Three main improvements: (1) Implement NSGA-II for true multi-objective optimization instead of weighted sum, (2) Add dynamic scheduling to handle new cases arriving during the scheduling period, (3) Conduct sensitivity analysis on the fuzzy rule weights to understand which rules have the most impact on scheduling outcomes.
