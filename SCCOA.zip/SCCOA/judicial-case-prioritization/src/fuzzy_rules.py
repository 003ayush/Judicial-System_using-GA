"""
Fuzzy Rule Base
================
Explicit, readable fuzzy rules for judicial case prioritization.

Each rule is a dictionary with:
  - id:           Rule identifier
  - description:  Human-readable explanation
  - antecedents:  List of (variable, linguistic_term) conditions
  - conjunction:  "AND" (min) or "OR" (max)
  - consequent:   Output linguistic term

Design Rationale:
  Rules are designed to capture common-sense judicial prioritization logic:
  - Old, severe cases need urgent attention
  - Vulnerable parties should not wait
  - High public interest demands timely resolution
  - Complexity alone should NOT deprioritize a case
  - Multiple urgent factors compound the priority

All rules are transparent and inspectable by stakeholders.
"""

# ── Rule Definitions ─────────────────────────────────────────

FUZZY_RULES = [
    # ── Very High Priority Rules ──────────────────────────────
    {
        "id": "R01",
        "description": "Old AND severe cases → Very High priority",
        "antecedents": [("age_years", "High"), ("severity", "High")],
        "conjunction": "AND",
        "consequent": "Very_High",
    },
    {
        "id": "R02",
        "description": "Old AND vulnerable parties → Very High priority",
        "antecedents": [("age_years", "High"), ("vulnerability", "High")],
        "conjunction": "AND",
        "consequent": "Very_High",
    },
    {
        "id": "R03",
        "description": "Severe AND high public interest → Very High priority",
        "antecedents": [("severity", "High"), ("public_interest", "High")],
        "conjunction": "AND",
        "consequent": "Very_High",
    },

    # ── High Priority Rules ───────────────────────────────────
    {
        "id": "R04",
        "description": "Old case with moderate severity → High priority",
        "antecedents": [("age_years", "High"), ("severity", "Medium")],
        "conjunction": "AND",
        "consequent": "High",
    },
    {
        "id": "R05",
        "description": "High vulnerability regardless of age → High priority",
        "antecedents": [("vulnerability", "High"), ("severity", "Medium")],
        "conjunction": "AND",
        "consequent": "High",
    },
    {
        "id": "R06",
        "description": "High public interest with moderate severity → High priority",
        "antecedents": [("public_interest", "High"), ("severity", "Medium")],
        "conjunction": "AND",
        "consequent": "High",
    },
    {
        "id": "R07",
        "description": "Moderate age but high severity → High priority",
        "antecedents": [("age_years", "Medium"), ("severity", "High")],
        "conjunction": "AND",
        "consequent": "High",
    },
    {
        "id": "R08",
        "description": "High complexity with high vulnerability → High priority",
        "antecedents": [("complexity", "High"), ("vulnerability", "High")],
        "conjunction": "AND",
        "consequent": "High",
    },

    # ── Medium Priority Rules ─────────────────────────────────
    {
        "id": "R09",
        "description": "Moderate age, moderate severity → Medium priority",
        "antecedents": [("age_years", "Medium"), ("severity", "Medium")],
        "conjunction": "AND",
        "consequent": "Medium",
    },
    {
        "id": "R10",
        "description": "High complexity but low urgency indicators → Medium priority",
        "antecedents": [("complexity", "High"), ("vulnerability", "Low")],
        "conjunction": "AND",
        "consequent": "Medium",
    },
    {
        "id": "R11",
        "description": "Moderate public interest, moderate severity → Medium priority",
        "antecedents": [("public_interest", "Medium"), ("severity", "Medium")],
        "conjunction": "AND",
        "consequent": "Medium",
    },
    {
        "id": "R12",
        "description": "Low age but high severity → Medium priority (new but urgent)",
        "antecedents": [("age_years", "Low"), ("severity", "High")],
        "conjunction": "AND",
        "consequent": "Medium",
    },

    # ── Low Priority Rules ────────────────────────────────────
    {
        "id": "R13",
        "description": "Low age AND low severity → Low priority",
        "antecedents": [("age_years", "Low"), ("severity", "Low")],
        "conjunction": "AND",
        "consequent": "Low",
    },
    {
        "id": "R14",
        "description": "Low severity AND low vulnerability → Low priority",
        "antecedents": [("severity", "Low"), ("vulnerability", "Low")],
        "conjunction": "AND",
        "consequent": "Low",
    },
    {
        "id": "R15",
        "description": "Low public interest AND low severity → Low priority",
        "antecedents": [("public_interest", "Low"), ("severity", "Low")],
        "conjunction": "AND",
        "consequent": "Low",
    },

    # ── Very Low Priority Rules ───────────────────────────────
    {
        "id": "R16",
        "description": "All urgency factors low → Very Low priority",
        "antecedents": [
            ("age_years", "Low"), ("severity", "Low"),
            ("public_interest", "Low"), ("vulnerability", "Low")
        ],
        "conjunction": "AND",
        "consequent": "Very_Low",
    },
]


def get_rules_table() -> list:
    """
    Return rules as a list of dictionaries suitable for tabular display.
    """
    rows = []
    for rule in FUZZY_RULES:
        antecedent_str = f" {rule['conjunction']} ".join(
            f"{var} IS {term}" for var, term in rule["antecedents"]
        )
        rows.append({
            "Rule ID": rule["id"],
            "IF": antecedent_str,
            "THEN Priority IS": rule["consequent"],
            "Description": rule["description"],
        })
    return rows


def get_rules_summary() -> str:
    """Return a formatted text summary of all rules."""
    lines = ["=" * 70, "FUZZY RULE BASE", "=" * 70]
    for rule in FUZZY_RULES:
        antecedent_str = f" {rule['conjunction']} ".join(
            f"{var} IS {term}" for var, term in rule["antecedents"]
        )
        lines.append(
            f"  {rule['id']}: IF {antecedent_str} "
            f"THEN priority IS {rule['consequent']}"
        )
        lines.append(f"         → {rule['description']}")
    lines.append("=" * 70)
    return "\n".join(lines)
