"""
Evaluation Module
==================
Comprehensive comparison of scheduling methods with statistical analysis.
"""

import numpy as np
import pandas as pd
import time
from typing import List, Dict, Optional

from src.config import (
    GA_POPULATION_SIZE, GA_GENERATIONS, GA_CROSSOVER_RATE,
    GA_MUTATION_RATE, GA_TOURNAMENT_SIZE, GA_ELITISM_COUNT,
    REPEATED_TRIAL_SEEDS, SENSITIVITY_PARAMS, DAILY_CAPACITY_HOURS,
)
from src.objective import compute_objective
from src.genetic_algorithm import GeneticAlgorithm
from src.baselines import run_all_baselines


def run_ga_experiment(
    priorities: np.ndarray,
    durations: np.ndarray,
    target_days: np.ndarray,
    case_types: np.ndarray = None,
    seed: int = 42,
    population_size: int = GA_POPULATION_SIZE,
    generations: int = GA_GENERATIONS,
    crossover_rate: float = GA_CROSSOVER_RATE,
    mutation_rate: float = GA_MUTATION_RATE,
    progress_callback=None,
    **kwargs,
) -> Dict:
    """
    Run a single GA optimization experiment.

    Returns a result dict compatible with baseline results.
    """
    n = len(priorities)

    def fitness_func(perm):
        return compute_objective(
            perm, priorities, durations, target_days, case_types, **kwargs
        )

    ga = GeneticAlgorithm(
        fitness_func=fitness_func,
        n_items=n,
        population_size=population_size,
        generations=generations,
        crossover_rate=crossover_rate,
        mutation_rate=mutation_rate,
        tournament_size=GA_TOURNAMENT_SIZE,
        elitism_count=GA_ELITISM_COUNT,
        seed=seed,
    )

    result = ga.run(progress_callback=progress_callback)

    return {
        "method": "Genetic Algorithm",
        "permutation": result.best_permutation,
        "objective": result.best_fitness,
        "runtime": result.runtime_seconds,
        "convergence_history": result.convergence_history,
        "avg_fitness_history": result.avg_fitness_history,
        "generations_run": result.generations_run,
        "population_size": result.population_size,
    }


def compare_methods(
    ages: np.ndarray,
    priorities: np.ndarray,
    durations: np.ndarray,
    target_days: np.ndarray,
    case_types: np.ndarray = None,
    seed: int = 42,
    ga_kwargs: dict = None,
    progress_callback=None,
) -> List[Dict]:
    """
    Run all methods (baselines + GA) and return comparison results.
    """
    # Run baselines
    baseline_results = run_all_baselines(
        ages, priorities, durations, target_days, case_types, seed=seed
    )

    # Run GA
    ga_kw = ga_kwargs or {}
    ga_result = run_ga_experiment(
        priorities, durations, target_days, case_types,
        seed=seed, progress_callback=progress_callback, **ga_kw
    )

    all_results = baseline_results + [ga_result]

    # Add additional metrics to each result
    for res in all_results:
        perm = res["permutation"]
        components = compute_objective(
            perm, priorities, durations, target_days, case_types,
            return_components=True
        )
        res["objective_components"] = components

        # Average scheduling position of top-20% priority cases
        n = len(priorities)
        top_k = max(1, n // 5)
        top_priority_indices = set(np.argsort(-priorities)[:top_k])
        positions = [
            pos for pos, idx in enumerate(perm) if idx in top_priority_indices
        ]
        res["avg_top_priority_position"] = np.mean(positions) if positions else n

    return all_results


def run_repeated_trials(
    ages: np.ndarray,
    priorities: np.ndarray,
    durations: np.ndarray,
    target_days: np.ndarray,
    case_types: np.ndarray = None,
    seeds: List[int] = None,
    progress_callback=None,
) -> pd.DataFrame:
    """
    Run experiments with multiple random seeds and collect statistics.

    Returns a DataFrame with one row per (method, seed) combination.
    """
    if seeds is None:
        seeds = REPEATED_TRIAL_SEEDS

    records = []
    for i, seed in enumerate(seeds):
        results = compare_methods(
            ages, priorities, durations, target_days, case_types, seed=seed
        )
        for res in results:
            records.append({
                "seed": seed,
                "method": res["method"],
                "objective": res["objective"],
                "runtime": res["runtime"],
                "avg_top_priority_position": res["avg_top_priority_position"],
                "pwc": res["objective_components"]["priority_weighted_completion"],
                "lateness": res["objective_components"]["lateness_penalty"],
                "capacity": res["objective_components"]["capacity_penalty"],
            })

        if progress_callback:
            progress_callback(i + 1, len(seeds))

    return pd.DataFrame(records)


def compute_trial_statistics(trial_df: pd.DataFrame) -> pd.DataFrame:
    """
    Compute summary statistics from repeated trial results.

    Returns one row per method with mean, std, min, max for key metrics.
    """
    stats = trial_df.groupby("method").agg(
        objective_mean=("objective", "mean"),
        objective_std=("objective", "std"),
        objective_min=("objective", "min"),
        objective_max=("objective", "max"),
        runtime_mean=("runtime", "mean"),
        runtime_std=("runtime", "std"),
        avg_top_pos_mean=("avg_top_priority_position", "mean"),
        pwc_mean=("pwc", "mean"),
        lateness_mean=("lateness", "mean"),
        capacity_mean=("capacity", "mean"),
    ).reset_index()

    return stats


def run_sensitivity_analysis(
    ages: np.ndarray,
    priorities: np.ndarray,
    durations: np.ndarray,
    target_days: np.ndarray,
    case_types: np.ndarray = None,
    param_name: str = "mutation_rate",
    param_values: list = None,
    seed: int = 42,
) -> pd.DataFrame:
    """
    Sensitivity analysis: vary one GA parameter and measure the objective.
    """
    if param_values is None:
        param_values = SENSITIVITY_PARAMS.get(param_name, [])

    records = []
    for val in param_values:
        kwargs = {param_name: val}
        result = run_ga_experiment(
            priorities, durations, target_days, case_types,
            seed=seed, **kwargs
        )
        records.append({
            "param_name": param_name,
            "param_value": val,
            "objective": result["objective"],
            "runtime": result["runtime"],
        })

    return pd.DataFrame(records)
