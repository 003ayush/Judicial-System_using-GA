"""
Scheduling Objective Function
===============================
Composite objective for evaluating a case scheduling permutation.

The objective measures the quality of a scheduling sequence by
considering multiple factors that a real court system would care about.

Objective = w1 * PriorityWeightedCompletion
           + w2 * LatenessPenalty
           + w3 * CapacityPenalty
           + w4 * ConcentrationPenalty

Lower objective value = better schedule.

NOTE: This is NOT an officially accepted judicial scheduling metric.
It is designed for academic demonstration of multi-objective optimization.
All coefficients are configurable.
"""

import numpy as np
from typing import List, Dict, Tuple

from src.config import OBJECTIVE_WEIGHTS, DAILY_CAPACITY_HOURS


def priority_weighted_completion(
    permutation: List[int],
    priorities: np.ndarray,
    durations: np.ndarray,
) -> float:
    """
    Priority-weighted completion time.

    High-priority cases scheduled later incur higher cost.

        C = Σ (priority_i / max_priority) * completion_time_i

    where completion_time_i is the cumulative hearing time up to case i.
    """
    max_p = priorities.max() if priorities.max() > 0 else 1.0
    cumulative_time = 0.0
    cost = 0.0

    for idx in permutation:
        cumulative_time += durations[idx]
        normalized_priority = priorities[idx] / max_p
        cost += normalized_priority * cumulative_time

    return cost


def lateness_penalty(
    permutation: List[int],
    durations: np.ndarray,
    target_days: np.ndarray,
    daily_hours: float = DAILY_CAPACITY_HOURS,
) -> float:
    """
    Penalty for cases scheduled past their target completion day.

        L = Σ max(0, completion_day_i - target_day_i)²

    Completion day is estimated from cumulative hearing time / daily capacity.
    """
    cumulative_time = 0.0
    penalty = 0.0

    for idx in permutation:
        cumulative_time += durations[idx]
        completion_day = cumulative_time / daily_hours
        lateness = max(0, completion_day - target_days[idx])
        penalty += lateness ** 2

    return penalty


def capacity_penalty(
    permutation: List[int],
    durations: np.ndarray,
    daily_hours: float = DAILY_CAPACITY_HOURS,
) -> float:
    """
    Penalty for exceeding daily hearing capacity.

    Simulates day-by-day scheduling: when a case would exceed the
    remaining hours in a day, it spills to the next day, creating
    idle time waste.

        P = Σ (idle_hours_per_day)²
    """
    day_used = 0.0
    penalty = 0.0

    for idx in permutation:
        dur = durations[idx]
        if day_used + dur > daily_hours:
            # Spill to next day — penalize the idle gap
            idle = daily_hours - day_used
            penalty += idle ** 2
            day_used = dur
        else:
            day_used += dur

    return penalty


def concentration_penalty(
    permutation: List[int],
    case_types: np.ndarray,
    window_size: int = 5,
) -> float:
    """
    Penalty for scheduling too many cases of the same type consecutively.

    Encourages variety in daily dockets (real courts handle mixed case types).

        P = Σ max(0, count_same_in_window - 3)²
    """
    penalty = 0.0
    n = len(permutation)

    for i in range(n):
        window_end = min(i + window_size, n)
        window_types = [case_types[permutation[j]] for j in range(i, window_end)]
        current_type = case_types[permutation[i]]
        same_count = sum(1 for t in window_types if t == current_type)
        if same_count > 3:
            penalty += (same_count - 3) ** 2

    return penalty


def compute_objective(
    permutation: List[int],
    priorities: np.ndarray,
    durations: np.ndarray,
    target_days: np.ndarray,
    case_types: np.ndarray = None,
    weights: Dict[str, float] = None,
    daily_hours: float = DAILY_CAPACITY_HOURS,
    return_components: bool = False,
) -> float | Dict:
    """
    Compute the composite scheduling objective.

    Parameters
    ----------
    permutation : List[int]
        Ordered list of case indices (scheduling sequence).
    priorities : np.ndarray
        Fuzzy priority scores for each case.
    durations : np.ndarray
        Hearing duration (hours) for each case.
    target_days : np.ndarray
        Target completion day for each case.
    case_types : np.ndarray, optional
        Case type labels (for concentration penalty).
    weights : dict, optional
        Objective weight overrides.
    daily_hours : float
        Daily hearing capacity.
    return_components : bool
        If True, return breakdown of each objective component.

    Returns
    -------
    float or Dict
        Total objective value (lower = better), or component breakdown.
    """
    if weights is None:
        weights = OBJECTIVE_WEIGHTS

    # Validate permutation
    assert len(permutation) == len(priorities), "Permutation length mismatch"
    assert set(permutation) == set(range(len(priorities))), "Invalid permutation"

    pwc = priority_weighted_completion(permutation, priorities, durations)
    lp = lateness_penalty(permutation, durations, target_days, daily_hours)
    cp = capacity_penalty(permutation, durations, daily_hours)

    total = (
        weights["priority_weighted_completion"] * pwc
        + weights["lateness_penalty"] * lp
        + weights["capacity_penalty"] * cp
    )

    conc_p = 0.0
    if case_types is not None and weights.get("concentration_penalty", 0) > 0:
        conc_p = concentration_penalty(permutation, case_types)
        total += weights["concentration_penalty"] * conc_p

    if return_components:
        return {
            "total": total,
            "priority_weighted_completion": pwc,
            "lateness_penalty": lp,
            "capacity_penalty": cp,
            "concentration_penalty": conc_p,
            "weights": weights,
        }

    return total


def validate_permutation(permutation: List[int], n_cases: int) -> bool:
    """
    Validate that a permutation is correct.

    Checks:
    - Correct length
    - Every case appears exactly once
    - All indices in valid range
    """
    if len(permutation) != n_cases:
        return False
    if set(permutation) != set(range(n_cases)):
        return False
    return True
