"""
Synthetic Dataset Generator
============================
Generates reproducible synthetic judicial case data for experimentation.

DISCLAIMER: All data is synthetic and does not represent actual court records.
The feature distributions are based on reasonable assumptions for academic
demonstration purposes only.

Assumptions documented:
- Case types follow approximate real-world distribution (Civil > Criminal > Family > Commercial > Constitutional)
- Age: 0.1–15 years, right-skewed (most cases 0–5 years, some very old)
- Severity: 1–10, varies by case type (Criminal tends higher)
- Complexity: 1–10, varies by case type (Constitutional/Commercial tend higher)
- Public interest: 1–10, varies by case type (Constitutional tends higher)
- Vulnerability: 1–10, slightly correlated with severity
- Hearing duration: 0.5–8 hours, correlated with complexity
- Target day: 1–60 days, lower for high-severity cases
- Pending documents: 0–20, slightly correlated with complexity
- Historical adjournments: 0–30, correlated with age
"""

import numpy as np
import pandas as pd
from pathlib import Path

from src.config import (
    RANDOM_SEED, NUM_CASES, CASE_TYPES, CASE_TYPE_WEIGHTS,
    FEATURE_RANGES, SYNTHETIC_CSV, DATA_DIR
)


def _clamp(value: float, low: float, high: float) -> float:
    """Clamp value to [low, high]."""
    return max(low, min(high, value))


def generate_cases(num_cases: int = NUM_CASES, seed: int = RANDOM_SEED) -> pd.DataFrame:
    """
    Generate a synthetic dataset of judicial cases.

    Parameters
    ----------
    num_cases : int
        Number of cases to generate.
    seed : int
        Random seed for reproducibility.

    Returns
    -------
    pd.DataFrame
        DataFrame with all case features.
    """
    rng = np.random.RandomState(seed)

    records = []
    for i in range(num_cases):
        case_id = f"CASE-{i + 1:04d}"

        # Case type with weighted probability
        case_type = rng.choice(CASE_TYPES, p=CASE_TYPE_WEIGHTS)

        # --- Age (years pending) ---
        # Right-skewed: most cases are recent, some very old
        age = rng.exponential(scale=3.0)
        age = _clamp(age, *FEATURE_RANGES["age_years"])
        age = round(age, 2)

        # --- Severity (1–10) ---
        # Criminal/Constitutional tend higher
        severity_base = {
            "Civil": 4.0, "Criminal": 6.5, "Family": 5.0,
            "Commercial": 4.5, "Constitutional": 6.0
        }[case_type]
        severity = rng.normal(loc=severity_base, scale=1.8)
        severity = int(_clamp(round(severity), *FEATURE_RANGES["severity"]))

        # --- Complexity (1–10) ---
        # Constitutional/Commercial tend more complex
        complexity_base = {
            "Civil": 4.5, "Criminal": 5.0, "Family": 4.0,
            "Commercial": 6.5, "Constitutional": 7.0
        }[case_type]
        complexity = rng.normal(loc=complexity_base, scale=1.5)
        complexity = int(_clamp(round(complexity), *FEATURE_RANGES["complexity"]))

        # --- Public Interest (1–10) ---
        # Constitutional cases have higher public interest
        pi_base = {
            "Civil": 3.0, "Criminal": 5.5, "Family": 3.5,
            "Commercial": 4.0, "Constitutional": 7.5
        }[case_type]
        public_interest = rng.normal(loc=pi_base, scale=2.0)
        public_interest = int(_clamp(round(public_interest), *FEATURE_RANGES["public_interest"]))

        # --- Vulnerability (1–10) ---
        # Slightly correlated with severity
        vulnerability = rng.normal(loc=0.4 * severity + 3.0, scale=1.5)
        vulnerability = int(_clamp(round(vulnerability), *FEATURE_RANGES["vulnerability"]))

        # --- Hearing Duration (hours) ---
        # Correlated with complexity
        hearing_dur = rng.normal(loc=0.5 * complexity + 0.5, scale=1.0)
        hearing_dur = round(_clamp(hearing_dur, *FEATURE_RANGES["hearing_duration"]), 1)

        # --- Target Day ---
        # High-severity cases have tighter deadlines
        target_base = max(5, 45 - 3 * severity)
        target_day = int(rng.normal(loc=target_base, scale=8))
        target_day = int(_clamp(target_day, *FEATURE_RANGES["target_day"]))

        # --- Pending Documents ---
        # Slightly correlated with complexity
        pending_docs = rng.poisson(lam=0.8 * complexity)
        pending_docs = int(_clamp(pending_docs, *FEATURE_RANGES["pending_documents"]))

        # --- Historical Adjournments ---
        # Correlated with age
        adj_base = max(0, age * 1.5)
        adjournments = rng.poisson(lam=adj_base + 1)
        adjournments = int(_clamp(adjournments, *FEATURE_RANGES["historical_adjournments"]))

        records.append({
            "case_id": case_id,
            "case_type": case_type,
            "age_years": age,
            "severity": severity,
            "complexity": complexity,
            "public_interest": public_interest,
            "vulnerability": vulnerability,
            "hearing_duration": hearing_dur,
            "target_day": target_day,
            "pending_documents": pending_docs,
            "historical_adjournments": adjournments,
        })

    df = pd.DataFrame(records)
    return df


def save_dataset(df: pd.DataFrame, filepath: Path = SYNTHETIC_CSV) -> Path:
    """Save dataset to CSV and return the path."""
    filepath.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(filepath, index=False)
    return filepath


def load_dataset(filepath: Path = SYNTHETIC_CSV) -> pd.DataFrame:
    """Load dataset from CSV."""
    return pd.read_csv(filepath)


if __name__ == "__main__":
    print("Generating synthetic judicial case dataset...")
    df = generate_cases()
    path = save_dataset(df)
    print(f"Generated {len(df)} cases → {path}")
    print(f"\nCase type distribution:\n{df['case_type'].value_counts()}")
    print(f"\nDataset preview:\n{df.head(10).to_string()}")
    print(f"\nDescriptive statistics:\n{df.describe().to_string()}")
