"""
Visualization Module
=====================
Research-quality charts and figures for the judicial case prioritization system.
All figures are saved to results/figures/ and can be displayed in the dashboard.
"""

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')  # Non-interactive backend for server/script use
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker
from pathlib import Path
from typing import List, Dict, Optional, Tuple

from src.config import (
    FUZZY_INPUT_MFS, FUZZY_OUTPUT_MFS,
    FUZZY_INPUT_RANGE, FUZZY_OUTPUT_RANGE,
    FIGURES_DIR,
)
from src.fuzzy_engine import get_mf_plot_data


# ── Style Configuration ──────────────────────────────────────

COLORS = {
    "GA":                     "#10B981",
    "Priority Sort":          "#6366F1",
    "FIFO (Oldest First)":    "#F59E0B",
    "Random":                 "#64748B",
    "Shortest Hearing First": "#0EA5E9",
    "Genetic Algorithm":      "#10B981",
}

STYLE_PARAMS = {
    "figure.facecolor": "#0F172A",
    "axes.facecolor":   "#131C31",
    "axes.edgecolor":   "#334155",
    "axes.labelcolor":  "#F1F5F9",
    "text.color":       "#F1F5F9",
    "xtick.color":      "#94A3B8",
    "ytick.color":      "#94A3B8",
    "grid.color":       "#1E293B",
    "grid.alpha":       0.7,
    "legend.facecolor": "#131C31",
    "legend.edgecolor": "#334155",
    "legend.labelcolor": "#F1F5F9",
    "font.size":        10,
}


def _apply_style():
    """Apply the dark research theme."""
    plt.rcParams.update(STYLE_PARAMS)


def _get_color(method_name: str) -> str:
    """Get color for a method."""
    return COLORS.get(method_name, "#9b59b6")


# ── Membership Function Plots ────────────────────────────────

def plot_input_membership_functions(save: bool = True) -> plt.Figure:
    """Plot input membership functions (Low, Medium, High)."""
    _apply_style()
    fig, ax = plt.subplots(figsize=(10, 5))

    plot_data = get_mf_plot_data(FUZZY_INPUT_MFS, FUZZY_INPUT_RANGE)

    colors = {"Low": "#3498db", "Medium": "#f39c12", "High": "#e74c3c"}
    for label, (x, y) in plot_data.items():
        ax.plot(x, y, linewidth=2.5, label=label, color=colors.get(label, "#fff"))
        ax.fill_between(x, y, alpha=0.15, color=colors.get(label, "#fff"))

    ax.set_xlabel("Input Value (Normalized 0-10)")
    ax.set_ylabel("Membership Degree")
    ax.set_title("Input Membership Functions", fontsize=14, fontweight="bold")
    ax.set_ylim(-0.05, 1.1)
    ax.legend(loc="upper right", fontsize=11)
    ax.grid(True, alpha=0.3)
    fig.tight_layout()

    if save:
        fig.savefig(FIGURES_DIR / "input_membership_functions.png", dpi=150, bbox_inches="tight")

    return fig


def plot_output_membership_functions(save: bool = True) -> plt.Figure:
    """Plot output membership functions (Very_Low to Very_High)."""
    _apply_style()
    fig, ax = plt.subplots(figsize=(10, 5))

    plot_data = get_mf_plot_data(FUZZY_OUTPUT_MFS, FUZZY_OUTPUT_RANGE)

    colors = {
        "Very_Low": "#3498db", "Low": "#2ecc71", "Medium": "#f39c12",
        "High": "#e67e22", "Very_High": "#e74c3c",
    }
    for label, (x, y) in plot_data.items():
        ax.plot(x, y, linewidth=2.5, label=label.replace("_", " "), color=colors.get(label, "#fff"))
        ax.fill_between(x, y, alpha=0.12, color=colors.get(label, "#fff"))

    ax.set_xlabel("Priority Score (0-100)")
    ax.set_ylabel("Membership Degree")
    ax.set_title("Output Membership Functions", fontsize=14, fontweight="bold")
    ax.set_ylim(-0.05, 1.1)
    ax.legend(loc="upper right", fontsize=10)
    ax.grid(True, alpha=0.3)
    fig.tight_layout()

    if save:
        fig.savefig(FIGURES_DIR / "output_membership_functions.png", dpi=150, bbox_inches="tight")

    return fig


# ── Priority Distribution ────────────────────────────────────

def plot_priority_distribution(
    priorities: np.ndarray,
    case_types: np.ndarray = None,
    save: bool = True
) -> plt.Figure:
    """Plot histogram of fuzzy priority scores, optionally colored by case type."""
    _apply_style()
    fig, ax = plt.subplots(figsize=(10, 5))

    if case_types is not None:
        unique_types = sorted(set(case_types))
        type_colors = {
            "Civil": "#38BDF8", "Criminal": "#F43F5E", "Family": "#10B981",
            "Commercial": "#F59E0B", "Constitutional": "#A855F7"
        }
        for ct in unique_types:
            mask = case_types == ct
            ax.hist(priorities[mask], bins=20, alpha=0.65,
                    label=ct, color=type_colors.get(ct, "#94A3B8"), edgecolor="none")
    else:
        ax.hist(priorities, bins=25, alpha=0.7, color="#3498db", edgecolor="none")

    ax.set_xlabel("Priority Score")
    ax.set_ylabel("Number of Cases")
    ax.set_title("Distribution of Fuzzy Priority Scores", fontsize=14, fontweight="bold")
    ax.legend(loc="upper right")
    ax.grid(True, alpha=0.3)
    fig.tight_layout()

    if save:
        fig.savefig(FIGURES_DIR / "priority_distribution.png", dpi=150, bbox_inches="tight")

    return fig


# ── Comparison Bar Chart ─────────────────────────────────────

def plot_comparison_bar(
    results: List[Dict],
    metric: str = "objective",
    title: str = "Scheduling Method Comparison",
    save: bool = True,
    filename: str = "comparison_bar.png",
) -> plt.Figure:
    """Bar chart comparing methods on a given metric."""
    _apply_style()
    fig, ax = plt.subplots(figsize=(10, 6))

    methods = [r["method"] for r in results]
    values = [r[metric] for r in results]
    colors = [_get_color(m) for m in methods]

    bars = ax.bar(range(len(methods)), values, color=colors, width=0.6, edgecolor="none")

    # Add value labels on bars
    for bar, val in zip(bars, values):
        y_pos = bar.get_height()
        ax.text(bar.get_x() + bar.get_width() / 2, y_pos * 1.02,
                f"{val:,.0f}" if val > 100 else f"{val:.2f}",
                ha="center", va="bottom", fontsize=10, fontweight="bold")

    ax.set_xticks(range(len(methods)))
    ax.set_xticklabels(methods, rotation=20, ha="right", fontsize=10)
    ax.set_ylabel(metric.replace("_", " ").title())
    ax.set_title(title, fontsize=14, fontweight="bold")
    ax.grid(True, axis="y", alpha=0.3)
    fig.tight_layout()

    if save:
        fig.savefig(FIGURES_DIR / filename, dpi=150, bbox_inches="tight")

    return fig


# ── Convergence Plot ──────────────────────────────────────────

def plot_convergence(
    convergence_history: List[float],
    avg_history: List[float] = None,
    save: bool = True,
) -> plt.Figure:
    """Plot GA convergence curve."""
    _apply_style()
    fig, ax = plt.subplots(figsize=(10, 5))

    gens = list(range(len(convergence_history)))
    ax.plot(gens, convergence_history, color="#2ecc71", linewidth=2, label="Best Fitness")

    if avg_history:
        ax.plot(gens[:len(avg_history)], avg_history, color="#e74c3c",
                linewidth=1.5, alpha=0.6, linestyle="--", label="Average Fitness")

    ax.set_xlabel("Generation")
    ax.set_ylabel("Objective Value (lower = better)")
    ax.set_title("Genetic Algorithm Convergence", fontsize=14, fontweight="bold")
    ax.legend(loc="upper right")
    ax.grid(True, alpha=0.3)
    fig.tight_layout()

    if save:
        fig.savefig(FIGURES_DIR / "convergence.png", dpi=150, bbox_inches="tight")

    return fig


# ── Sensitivity Plot ──────────────────────────────────────────

def plot_sensitivity(
    sens_df: pd.DataFrame,
    save: bool = True,
) -> plt.Figure:
    """Plot sensitivity analysis results."""
    _apply_style()
    param_name = sens_df["param_name"].iloc[0]

    fig, ax1 = plt.subplots(figsize=(10, 5))

    ax1.plot(sens_df["param_value"], sens_df["objective"],
             "o-", color="#2ecc71", linewidth=2, markersize=8, label="Objective")
    ax1.set_xlabel(param_name.replace("_", " ").title())
    ax1.set_ylabel("Objective Value", color="#2ecc71")
    ax1.tick_params(axis="y", labelcolor="#2ecc71")

    ax2 = ax1.twinx()
    ax2.plot(sens_df["param_value"], sens_df["runtime"],
             "s--", color="#e74c3c", linewidth=1.5, markersize=6, alpha=0.7, label="Runtime")
    ax2.set_ylabel("Runtime (s)", color="#e74c3c")
    ax2.tick_params(axis="y", labelcolor="#e74c3c")

    ax1.set_title(f"Sensitivity Analysis: {param_name.replace('_', ' ').title()}",
                  fontsize=14, fontweight="bold")
    ax1.grid(True, alpha=0.3)

    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines1 + lines2, labels1 + labels2, loc="upper right")

    fig.tight_layout()

    if save:
        fig.savefig(FIGURES_DIR / f"sensitivity_{param_name}.png", dpi=150, bbox_inches="tight")

    return fig


# ── Repeated Trials Box Plot ─────────────────────────────────

def plot_repeated_trials(
    trial_df: pd.DataFrame,
    save: bool = True,
) -> plt.Figure:
    """Box plot of objective values across repeated trials."""
    _apply_style()
    fig, ax = plt.subplots(figsize=(10, 6))

    methods = sorted(trial_df["method"].unique())
    data = [trial_df[trial_df["method"] == m]["objective"].values for m in methods]
    colors_list = [_get_color(m) for m in methods]

    bp = ax.boxplot(data, patch_artist=True, tick_labels=methods,
                    medianprops=dict(color="white", linewidth=2))

    for patch, color in zip(bp["boxes"], colors_list):
        patch.set_facecolor(color)
        patch.set_alpha(0.7)

    ax.set_ylabel("Objective Value")
    ax.set_title("Objective Distribution Across Repeated Trials", fontsize=14, fontweight="bold")
    ax.set_xticklabels(methods, rotation=20, ha="right")
    ax.grid(True, axis="y", alpha=0.3)
    fig.tight_layout()

    if save:
        fig.savefig(FIGURES_DIR / "repeated_trials_boxplot.png", dpi=150, bbox_inches="tight")

    return fig


# ── Generate All Figures ──────────────────────────────────────

def generate_all_figures(
    priorities: np.ndarray,
    case_types: np.ndarray,
    results: List[Dict],
    trial_df: pd.DataFrame = None,
    sens_df: pd.DataFrame = None,
):
    """Generate all standard figures."""
    print("Generating figures...")

    plot_input_membership_functions()
    print("  - Input MF plot")

    plot_output_membership_functions()
    print("  - Output MF plot")

    plot_priority_distribution(priorities, case_types)
    print("  - Priority distribution")

    plot_comparison_bar(results)
    print("  - Comparison bar chart")

    # Find GA result for convergence
    ga_results = [r for r in results if r["method"] == "Genetic Algorithm"]
    if ga_results and "convergence_history" in ga_results[0]:
        plot_convergence(
            ga_results[0]["convergence_history"],
            ga_results[0].get("avg_fitness_history"),
        )
        print("  - Convergence plot")

    if trial_df is not None and not trial_df.empty:
        plot_repeated_trials(trial_df)
        print("  - Repeated trials box plot")

    if sens_df is not None and not sens_df.empty:
        plot_sensitivity(sens_df)
        print("  - Sensitivity plot")

    print(f"All figures saved to {FIGURES_DIR}")
