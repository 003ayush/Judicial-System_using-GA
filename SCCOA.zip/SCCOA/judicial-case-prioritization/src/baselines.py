"""
Baseline Scheduling Methods
=============================
Implements simple scheduling strategies for comparison with the GA.

Each baseline returns the same interface:
  - scheduling permutation (list of int)
  - objective value
  - runtime in seconds
"""

import time
import numpy as np
from typing import List, Dict
from src.objective import compute_objective


def fifo_schedule(
    ages: np.ndarray,
    priorities: np.ndarray,
    durations: np.ndarray,
    target_days: np.ndarray,
    case_types: np.ndarray = None,
    **kwargs,
) -> Dict:
    """
    FIFO: Schedule cases by age (oldest first).

    Rationale: Simple queue discipline — cases that have waited
    longest are heard first.
    """
    start = time.time()

    # Sort by age descending (oldest first)
    permutation = list(np.argsort(-ages))

    objective = compute_objective(
        permutation, priorities, durations, target_days, case_types, **kwargs
    )

    return {
        "method": "FIFO (Oldest First)",
        "permutation": permutation,
        "objective": objective,
        "runtime": time.time() - start,
    }


def priority_sort_schedule(
    priorities: np.ndarray,
    durations: np.ndarray,
    target_days: np.ndarray,
    case_types: np.ndarray = None,
    **kwargs,
) -> Dict:
    """
    Priority Sort: Schedule by descending fuzzy priority score.

    Rationale: Highest-priority cases first — the most intuitive
    use of the fuzzy scores.
    """
    start = time.time()

    permutation = list(np.argsort(-priorities))

    objective = compute_objective(
        permutation, priorities, durations, target_days, case_types, **kwargs
    )

    return {
        "method": "Priority Sort",
        "permutation": permutation,
        "objective": objective,
        "runtime": time.time() - start,
    }


def random_schedule(
    n_cases: int,
    priorities: np.ndarray,
    durations: np.ndarray,
    target_days: np.ndarray,
    case_types: np.ndarray = None,
    seed: int = 42,
    **kwargs,
) -> Dict:
    """
    Random: Shuffle cases randomly.

    Rationale: Worst-case baseline — no intelligent ordering.
    """
    start = time.time()
    rng = np.random.RandomState(seed)

    permutation = list(range(n_cases))
    rng.shuffle(permutation)

    objective = compute_objective(
        permutation, priorities, durations, target_days, case_types, **kwargs
    )

    return {
        "method": "Random",
        "permutation": permutation,
        "objective": objective,
        "runtime": time.time() - start,
    }


def shortest_hearing_first(
    durations: np.ndarray,
    priorities: np.ndarray,
    target_days: np.ndarray,
    case_types: np.ndarray = None,
    **kwargs,
) -> Dict:
    """
    Shortest Hearing First (SHF): Schedule by ascending hearing duration.

    Rationale: Maximize the number of cases heard per day.
    Similar to Shortest Job First in OS scheduling.
    """
    start = time.time()

    permutation = list(np.argsort(durations))

    objective = compute_objective(
        permutation, priorities, durations, target_days, case_types, **kwargs
    )

    return {
        "method": "Shortest Hearing First",
        "permutation": permutation,
        "objective": objective,
        "runtime": time.time() - start,
    }


def run_all_baselines(
    ages: np.ndarray,
    priorities: np.ndarray,
    durations: np.ndarray,
    target_days: np.ndarray,
    case_types: np.ndarray = None,
    seed: int = 42,
    **kwargs,
) -> List[Dict]:
    """
    Run all baseline methods and return results.
    """
    n_cases = len(priorities)
    results = [
        fifo_schedule(ages, priorities, durations, target_days, case_types, **kwargs),
        priority_sort_schedule(priorities, durations, target_days, case_types, **kwargs),
        random_schedule(n_cases, priorities, durations, target_days, case_types, seed=seed, **kwargs),
        shortest_hearing_first(durations, priorities, target_days, case_types, **kwargs),
    ]
    return results
