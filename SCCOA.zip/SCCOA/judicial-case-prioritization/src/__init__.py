"""
Judicial Case Prioritization System
====================================
Fuzzy–Hybrid Judicial Case Prioritization Using Genetic Algorithm
for Court Backlog Optimization.

Explainable research prototype
Department: CSE (AI & ML)

DISCLAIMER: This is a synthetic, academic decision-support prototype.
It does NOT make real judicial decisions and must NOT be used as an
operational court-management product.
"""

__version__ = "1.0.0"
__project__ = "Fuzzy-Hybrid Judicial Case Prioritization"
