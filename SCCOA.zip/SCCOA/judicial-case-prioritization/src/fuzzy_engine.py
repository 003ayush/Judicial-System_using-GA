"""
Fuzzy Inference Engine
=======================
Custom, transparent fuzzy inference implementation for case prioritization.

This module implements a fuzzy-style weighted scoring approach using:
  - Triangular and trapezoidal membership functions
  - Explicit, readable fuzzy rules (defined in fuzzy_rules.py)
  - Min-based conjunction (AND), Max-based disjunction (OR)
  - Centroid defuzzification

Design Choice:
  We implement a Mamdani-style fuzzy inference system from scratch
  rather than using opaque library calls, so every step is transparent,
  auditable, and reproducible for academic purposes.

Pipeline:
  1. Fuzzification  — map crisp inputs to membership degrees
  2. Rule Evaluation — evaluate all rules, compute firing strengths
  3. Aggregation     — combine consequent fuzzy sets
  4. Defuzzification — centroid method to obtain crisp priority score
"""

import numpy as np
from typing import Dict, List, Tuple

from src.config import (
    FUZZY_INPUT_MFS, FUZZY_OUTPUT_MFS,
    FUZZY_INPUT_RANGE, FUZZY_OUTPUT_RANGE,
    FUZZY_INPUTS,
)


# ── Membership Functions ────────────────────────────────────

def triangular_mf(x: float, a: float, b: float, c: float) -> float:
    """
    Triangular membership function.

        μ(x) = 0           if x ≤ a or x ≥ c
             = (x - a)/(b - a)  if a < x ≤ b
             = (c - x)/(c - b)  if b < x < c

    Parameters: a (left foot), b (peak), c (right foot)
    """
    if b == a:
        left = 1.0 if x >= a else 0.0
    else:
        left = (x - a) / (b - a)

    if c == b:
        right = 1.0 if x <= c else 0.0
    else:
        right = (c - x) / (c - b)

    return float(max(min(left, right), 0.0))


def trapezoidal_mf(x: float, a: float, b: float, c: float, d: float) -> float:
    """
    Trapezoidal membership function.

        μ(x) = 0                if x ≤ a or x ≥ d
             = (x - a)/(b - a)  if a < x < b
             = 1                if b ≤ x ≤ c
             = (d - x)/(d - c)  if c < x < d

    Parameters: a (left foot), b (left shoulder), c (right shoulder), d (right foot)
    """
    if b == a:
        left = 1.0 if x >= a else 0.0
    else:
        left = (x - a) / (b - a)

    if d == c:
        right = 1.0 if x <= c else 0.0
    else:
        right = (d - x) / (d - c)

    return float(max(min(left, right, 1.0), 0.0))


def evaluate_mf(x: float, mf_type: str, params: tuple) -> float:
    """Evaluate a membership function given its type and parameters."""
    if mf_type == "triangular":
        return triangular_mf(x, *params)
    elif mf_type == "trapezoidal":
        return trapezoidal_mf(x, *params)
    else:
        raise ValueError(f"Unknown MF type: {mf_type}")


# ── Fuzzification ────────────────────────────────────────────

def fuzzify_input(value: float, mf_definitions: Dict = None) -> Dict[str, float]:
    """
    Fuzzify a single input value using the configured membership functions.

    Parameters
    ----------
    value : float
        Crisp input value (expected in FUZZY_INPUT_RANGE).
    mf_definitions : dict, optional
        Override MF definitions. Defaults to FUZZY_INPUT_MFS.

    Returns
    -------
    Dict[str, float]
        Membership degrees for each linguistic term.
        Example: {"Low": 0.3, "Medium": 0.7, "High": 0.0}
    """
    if mf_definitions is None:
        mf_definitions = FUZZY_INPUT_MFS

    memberships = {}
    for label, (mf_type, params) in mf_definitions.items():
        memberships[label] = evaluate_mf(value, mf_type, params)

    return memberships


def fuzzify_all_inputs(input_values: Dict[str, float]) -> Dict[str, Dict[str, float]]:
    """
    Fuzzify all input variables.

    Parameters
    ----------
    input_values : Dict[str, float]
        Mapping of variable name → crisp value (normalized to 0–10).

    Returns
    -------
    Dict[str, Dict[str, float]]
        Mapping of variable name → {linguistic_term: membership_degree}.
    """
    fuzzified = {}
    for var_name, value in input_values.items():
        fuzzified[var_name] = fuzzify_input(value)
    return fuzzified


# ── Rule Evaluation ──────────────────────────────────────────

def evaluate_rule(
    antecedents: List[Tuple[str, str]],
    fuzzified: Dict[str, Dict[str, float]],
    conjunction: str = "AND"
) -> float:
    """
    Evaluate a single fuzzy rule's firing strength.

    Parameters
    ----------
    antecedents : list of (variable_name, linguistic_term) tuples
        Example: [("age_years", "High"), ("severity", "High")]
    fuzzified : dict
        Output of fuzzify_all_inputs.
    conjunction : str
        "AND" uses min, "OR" uses max.

    Returns
    -------
    float
        Firing strength of the rule.
    """
    degrees = []
    for var_name, term in antecedents:
        if var_name in fuzzified and term in fuzzified[var_name]:
            degrees.append(fuzzified[var_name][term])
        else:
            degrees.append(0.0)

    if not degrees:
        return 0.0

    if conjunction == "AND":
        return min(degrees)
    elif conjunction == "OR":
        return max(degrees)
    else:
        raise ValueError(f"Unknown conjunction: {conjunction}")


# ── Aggregation & Defuzzification ────────────────────────────

def aggregate_output(
    rule_results: List[Tuple[float, str]],
    output_mfs: Dict = None,
    resolution: int = 200
) -> Tuple[np.ndarray, np.ndarray]:
    """
    Aggregate rule outputs into a combined fuzzy output set.

    Uses max-aggregation: for each point in the output universe,
    the aggregated membership is the max of all clipped consequent MFs.

    Parameters
    ----------
    rule_results : list of (firing_strength, consequent_label)
        Example: [(0.7, "High"), (0.3, "Medium")]
    output_mfs : dict, optional
        Output membership function definitions.
    resolution : int
        Number of points for the output universe.

    Returns
    -------
    Tuple[np.ndarray, np.ndarray]
        (x_values, aggregated_membership_values)
    """
    if output_mfs is None:
        output_mfs = FUZZY_OUTPUT_MFS

    lo, hi = FUZZY_OUTPUT_RANGE
    x = np.linspace(lo, hi, resolution)
    aggregated = np.zeros(resolution)

    for firing_strength, consequent_label in rule_results:
        if firing_strength <= 0 or consequent_label not in output_mfs:
            continue

        mf_type, params = output_mfs[consequent_label]
        for i, xi in enumerate(x):
            mf_val = evaluate_mf(xi, mf_type, params)
            # Clip (Mamdani implication: min of firing strength and MF)
            clipped = min(firing_strength, mf_val)
            # Max aggregation
            aggregated[i] = max(aggregated[i], clipped)

    return x, aggregated


def defuzzify_centroid(x: np.ndarray, mf_values: np.ndarray) -> float:
    """
    Centroid (center of gravity) defuzzification.

        x* = Σ(x_i · μ(x_i)) / Σ(μ(x_i))

    Returns
    -------
    float
        Crisp output value. Returns midpoint of range if area is zero.
    """
    total_area = np.sum(mf_values)
    if total_area == 0:
        # No rules fired — return midpoint
        return float((x[0] + x[-1]) / 2)
    return float(np.sum(x * mf_values) / total_area)


# ── Complete Inference Pipeline ──────────────────────────────

def compute_priority(
    input_values: Dict[str, float],
    rules: List[Dict] = None,
    return_details: bool = False
) -> float | Dict:
    """
    Complete fuzzy inference pipeline for a single case.

    Parameters
    ----------
    input_values : Dict[str, float]
        Normalized input values (0–10 scale).
        Keys must be from FUZZY_INPUTS.
    rules : list of dict, optional
        Fuzzy rules. Each rule is a dict with keys:
          - "antecedents": list of (var_name, term) tuples
          - "conjunction": "AND" or "OR"
          - "consequent": output linguistic term
        Defaults to rules from fuzzy_rules module.
    return_details : bool
        If True, return a dict with intermediate results for explainability.

    Returns
    -------
    float or Dict
        Priority score (0–100), or detailed breakdown if return_details=True.
    """
    # Import rules lazily to avoid circular imports
    if rules is None:
        from src.fuzzy_rules import FUZZY_RULES
        rules = FUZZY_RULES

    # Step 1: Fuzzification
    fuzzified = fuzzify_all_inputs(input_values)

    # Step 2: Rule evaluation
    rule_results = []
    rule_details = []
    for rule in rules:
        strength = evaluate_rule(
            rule["antecedents"],
            fuzzified,
            rule.get("conjunction", "AND")
        )
        rule_results.append((strength, rule["consequent"]))
        if return_details:
            rule_details.append({
                "rule_id": rule.get("id", "?"),
                "description": rule.get("description", ""),
                "antecedents": rule["antecedents"],
                "consequent": rule["consequent"],
                "firing_strength": round(strength, 4),
            })

    # Step 3: Aggregation
    x, aggregated = aggregate_output(rule_results)

    # Step 4: Defuzzification
    priority = defuzzify_centroid(x, aggregated)

    # Clamp to valid range
    priority = max(FUZZY_OUTPUT_RANGE[0], min(FUZZY_OUTPUT_RANGE[1], priority))

    if return_details:
        return {
            "priority_score": round(priority, 2),
            "fuzzified_inputs": {
                k: {t: round(v, 4) for t, v in d.items()}
                for k, d in fuzzified.items()
            },
            "rule_evaluations": rule_details,
            "active_rules": sum(1 for s, _ in rule_results if s > 0),
            "total_rules": len(rules),
        }

    return round(priority, 2)


def compute_all_priorities(
    df,
    fuzzy_input_cols: List[str] = None
) -> list:
    """
    Compute fuzzy priority scores for all cases in a DataFrame.

    Parameters
    ----------
    df : pd.DataFrame
        Must contain normalized columns (e.g., age_years_norm).
    fuzzy_input_cols : list, optional
        Column names for fuzzy inputs. Defaults to FUZZY_INPUTS with _norm suffix.

    Returns
    -------
    list of float
        Priority scores for each case.
    """
    if fuzzy_input_cols is None:
        fuzzy_input_cols = [f"{c}_norm" for c in FUZZY_INPUTS]

    scores = []
    for _, row in df.iterrows():
        input_vals = {
            orig: row[norm_col]
            for orig, norm_col in zip(FUZZY_INPUTS, fuzzy_input_cols)
        }
        score = compute_priority(input_vals)
        scores.append(score)

    return scores


# ── Visualization Helpers ────────────────────────────────────

def get_mf_plot_data(
    mf_definitions: Dict,
    universe_range: Tuple[float, float],
    resolution: int = 200
) -> Dict[str, Tuple[np.ndarray, np.ndarray]]:
    """
    Generate plot data for membership functions.

    Returns dict of {label: (x_array, y_array)}.
    """
    lo, hi = universe_range
    x = np.linspace(lo, hi, resolution)

    plot_data = {}
    for label, (mf_type, params) in mf_definitions.items():
        y = np.array([evaluate_mf(xi, mf_type, params) for xi in x])
        plot_data[label] = (x, y)

    return plot_data
