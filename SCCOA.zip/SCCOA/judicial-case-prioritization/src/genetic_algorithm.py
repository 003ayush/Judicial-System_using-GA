"""
Genetic Algorithm for Case Scheduling
=======================================
Permutation-based GA that optimizes the scheduling sequence of judicial cases.

Representation:
  - Chromosome = permutation of case indices [0, 1, ..., n-1]
  - Each permutation represents a unique scheduling order

Operators:
  - Tournament selection
  - Order crossover (OX) — preserves permutation validity
  - Swap mutation — preserves permutation validity
  - Elitism — best solutions survive unchanged

All operators are permutation-preserving by construction.
"""

import numpy as np
import time
from typing import List, Dict, Tuple, Callable, Optional
from dataclasses import dataclass, field

from src.config import (
    GA_POPULATION_SIZE, GA_GENERATIONS, GA_CROSSOVER_RATE,
    GA_MUTATION_RATE, GA_TOURNAMENT_SIZE, GA_ELITISM_COUNT,
)


@dataclass
class GAResult:
    """Container for GA execution results."""
    best_permutation: List[int]
    best_fitness: float
    convergence_history: List[float]
    avg_fitness_history: List[float]
    runtime_seconds: float
    generations_run: int
    population_size: int
    final_population_best: List[int] = field(default_factory=list)


class GeneticAlgorithm:
    """
    Genetic Algorithm for permutation-based scheduling optimization.

    Parameters
    ----------
    fitness_func : Callable
        Function that takes a permutation (list of int) and returns
        a float fitness value. LOWER is better.
    n_items : int
        Number of items to schedule (length of permutation).
    population_size : int
        Number of individuals in the population.
    generations : int
        Maximum number of generations.
    crossover_rate : float
        Probability of applying crossover.
    mutation_rate : float
        Probability of applying mutation to each offspring.
    tournament_size : int
        Number of individuals in tournament selection.
    elitism_count : int
        Number of best individuals to preserve.
    seed : int, optional
        Random seed for reproducibility.
    """

    def __init__(
        self,
        fitness_func: Callable[[List[int]], float],
        n_items: int,
        population_size: int = GA_POPULATION_SIZE,
        generations: int = GA_GENERATIONS,
        crossover_rate: float = GA_CROSSOVER_RATE,
        mutation_rate: float = GA_MUTATION_RATE,
        tournament_size: int = GA_TOURNAMENT_SIZE,
        elitism_count: int = GA_ELITISM_COUNT,
        seed: Optional[int] = None,
    ):
        self.fitness_func = fitness_func
        self.n_items = n_items
        self.population_size = population_size
        self.generations = generations
        self.crossover_rate = crossover_rate
        self.mutation_rate = mutation_rate
        self.tournament_size = tournament_size
        self.elitism_count = elitism_count
        self.rng = np.random.RandomState(seed)

    # ── Population Initialization ─────────────────────────────

    def _init_population(self) -> List[List[int]]:
        """Create initial population of random permutations."""
        population = []
        base = list(range(self.n_items))
        for _ in range(self.population_size):
            perm = base.copy()
            self.rng.shuffle(perm)
            population.append(perm)
        return population

    # ── Selection ─────────────────────────────────────────────

    def _tournament_select(
        self, population: List[List[int]], fitnesses: List[float]
    ) -> List[int]:
        """
        Tournament selection: pick tournament_size random individuals,
        return the one with the best (lowest) fitness.
        """
        indices = self.rng.choice(
            len(population), size=self.tournament_size, replace=False
        )
        best_idx = min(indices, key=lambda i: fitnesses[i])
        return population[best_idx].copy()

    # ── Crossover ─────────────────────────────────────────────

    def _order_crossover(
        self, parent1: List[int], parent2: List[int]
    ) -> Tuple[List[int], List[int]]:
        """
        Order Crossover (OX):
        1. Select a random substring from parent1
        2. Copy it to child1 in the same positions
        3. Fill remaining positions with values from parent2 in order

        This always produces valid permutations.
        """
        n = self.n_items
        # Select two crossover points
        cx1, cx2 = sorted(self.rng.choice(n, size=2, replace=False))

        # Child 1
        child1 = [-1] * n
        child1[cx1:cx2 + 1] = parent1[cx1:cx2 + 1]
        used1 = set(child1[cx1:cx2 + 1])
        fill_values = [v for v in parent2 if v not in used1]
        fill_idx = 0
        for i in range(n):
            if child1[i] == -1:
                child1[i] = fill_values[fill_idx]
                fill_idx += 1

        # Child 2
        child2 = [-1] * n
        child2[cx1:cx2 + 1] = parent2[cx1:cx2 + 1]
        used2 = set(child2[cx1:cx2 + 1])
        fill_values = [v for v in parent1 if v not in used2]
        fill_idx = 0
        for i in range(n):
            if child2[i] == -1:
                child2[i] = fill_values[fill_idx]
                fill_idx += 1

        return child1, child2

    # ── Mutation ──────────────────────────────────────────────

    def _swap_mutation(self, individual: List[int]) -> List[int]:
        """
        Swap mutation: randomly swap two positions.
        Always preserves permutation validity.
        """
        result = individual.copy()
        i, j = self.rng.choice(self.n_items, size=2, replace=False)
        result[i], result[j] = result[j], result[i]
        return result

    # ── Main Evolution Loop ───────────────────────────────────

    def run(self, progress_callback: Optional[Callable] = None) -> GAResult:
        """
        Execute the genetic algorithm.

        Parameters
        ----------
        progress_callback : callable, optional
            Called each generation with (generation, best_fitness, avg_fitness).

        Returns
        -------
        GAResult
            Complete results including best solution and convergence history.
        """
        start_time = time.time()

        # Initialize
        population = self._init_population()
        fitnesses = [self.fitness_func(ind) for ind in population]

        best_ever_fitness = min(fitnesses)
        best_ever_idx = fitnesses.index(best_ever_fitness)
        best_ever = population[best_ever_idx].copy()

        convergence = [best_ever_fitness]
        avg_history = [np.mean(fitnesses)]

        for gen in range(self.generations):
            # Sort by fitness (ascending — lower is better)
            sorted_pairs = sorted(zip(fitnesses, population), key=lambda x: x[0])
            sorted_fitnesses = [p[0] for p in sorted_pairs]
            sorted_population = [p[1] for p in sorted_pairs]

            # Elitism: carry forward best individuals
            new_population = [ind.copy() for ind in sorted_population[:self.elitism_count]]
            new_fitnesses = sorted_fitnesses[:self.elitism_count]

            # Generate offspring
            while len(new_population) < self.population_size:
                parent1 = self._tournament_select(population, fitnesses)
                parent2 = self._tournament_select(population, fitnesses)

                # Crossover
                if self.rng.random() < self.crossover_rate:
                    child1, child2 = self._order_crossover(parent1, parent2)
                else:
                    child1, child2 = parent1.copy(), parent2.copy()

                # Mutation
                if self.rng.random() < self.mutation_rate:
                    child1 = self._swap_mutation(child1)
                if self.rng.random() < self.mutation_rate:
                    child2 = self._swap_mutation(child2)

                new_population.append(child1)
                if len(new_population) < self.population_size:
                    new_population.append(child2)

            # Evaluate new population
            population = new_population[:self.population_size]
            fitnesses = [self.fitness_func(ind) for ind in population]

            # Track best
            gen_best_fitness = min(fitnesses)
            gen_avg_fitness = np.mean(fitnesses)

            if gen_best_fitness < best_ever_fitness:
                best_ever_fitness = gen_best_fitness
                best_ever_idx = fitnesses.index(gen_best_fitness)
                best_ever = population[best_ever_idx].copy()

            convergence.append(best_ever_fitness)
            avg_history.append(gen_avg_fitness)

            if progress_callback:
                progress_callback(gen + 1, best_ever_fitness, gen_avg_fitness)

        runtime = time.time() - start_time

        return GAResult(
            best_permutation=best_ever,
            best_fitness=best_ever_fitness,
            convergence_history=convergence,
            avg_fitness_history=avg_history,
            runtime_seconds=runtime,
            generations_run=self.generations,
            population_size=self.population_size,
        )
