"""
Data Preprocessing Module
==========================
Validates, cleans, and normalizes the synthetic dataset.
Produces a data-quality summary and prepares features for
fuzzy inference.
"""

import numpy as np
import pandas as pd
from pathlib import Path
from typing import Dict, Tuple

from src.config import (
    FEATURE_RANGES, FUZZY_INPUTS, FUZZY_INPUT_RANGE,
    PROCESSED_DIR, SYNTHETIC_CSV
)


# ── Feature Descriptions ──────────────────────────────────────
FEATURE_DESCRIPTIONS = {
    "case_id":                  "Unique identifier for each case",
    "case_type":                "Category: Civil, Criminal, Family, Commercial, Constitutional",
    "age_years":                "Years the case has been pending (0.1–15)",
    "severity":                 "Severity rating (1=minor, 10=critical)",
    "complexity":               "Legal/procedural complexity (1=simple, 10=very complex)",
    "public_interest":          "Level of public/societal interest (1=private, 10=national)",
    "vulnerability":            "Urgency due to vulnerable parties (1=low, 10=extreme)",
    "hearing_duration":         "Estimated hours per hearing session (0.5–8)",
    "target_day":               "Ideal completion within N days (1–60)",
    "pending_documents":        "Number of outstanding documents (0–20)",
    "historical_adjournments":  "Number of past adjournments (0–30)",
    "priority_score":           "Fuzzy-computed priority score (0–100) [added after fuzzy inference]",
}


def validate_dataset(df: pd.DataFrame) -> Dict:
    """
    Run data-quality checks on the dataset.

    Returns a dictionary with validation results.
    """
    report = {
        "total_records": len(df),
        "duplicates": int(df.duplicated(subset=["case_id"]).sum()),
        "missing_values": df.isnull().sum().to_dict(),
        "total_missing": int(df.isnull().sum().sum()),
        "range_violations": {},
        "data_types": df.dtypes.astype(str).to_dict(),
    }

    # Check ranges for numeric features
    for col, (lo, hi) in FEATURE_RANGES.items():
        if col in df.columns:
            below = int((df[col] < lo).sum())
            above = int((df[col] > hi).sum())
            if below > 0 or above > 0:
                report["range_violations"][col] = {
                    "below_min": below,
                    "above_max": above,
                }

    report["is_clean"] = (
        report["total_missing"] == 0
        and report["duplicates"] == 0
        and len(report["range_violations"]) == 0
    )

    return report


def normalize_for_fuzzy(df: pd.DataFrame) -> pd.DataFrame:
    """
    Normalize fuzzy input features to the fuzzy input range [0, 10].

    Uses min-max normalization based on the configured feature ranges.

    Parameters
    ----------
    df : pd.DataFrame
        Raw or validated dataset.

    Returns
    -------
    pd.DataFrame
        Copy of the dataframe with `_norm` columns added for each fuzzy input.
    """
    out = df.copy()
    lo, hi = FUZZY_INPUT_RANGE  # (0, 10)

    for col in FUZZY_INPUTS:
        feat_lo, feat_hi = FEATURE_RANGES[col]
        # Min-max scale to [0, 10]
        out[f"{col}_norm"] = (
            (out[col] - feat_lo) / (feat_hi - feat_lo) * (hi - lo) + lo
        )
        # Clamp to range
        out[f"{col}_norm"] = out[f"{col}_norm"].clip(lo, hi)

    return out


def get_descriptive_stats(df: pd.DataFrame) -> pd.DataFrame:
    """Return descriptive statistics for numeric columns."""
    numeric_cols = df.select_dtypes(include=[np.number]).columns
    return df[numeric_cols].describe().T


def preprocess(df: pd.DataFrame) -> Tuple[pd.DataFrame, Dict]:
    """
    Full preprocessing pipeline.

    1. Validate
    2. Normalize fuzzy inputs
    3. Return processed dataframe and quality report

    Parameters
    ----------
    df : pd.DataFrame
        Raw synthetic dataset.

    Returns
    -------
    Tuple[pd.DataFrame, Dict]
        (processed_df, quality_report)
    """
    report = validate_dataset(df)

    # Remove duplicates if any
    if report["duplicates"] > 0:
        df = df.drop_duplicates(subset=["case_id"])
        report["duplicates_removed"] = True

    # Normalize for fuzzy inference
    processed = normalize_for_fuzzy(df)

    return processed, report


def save_processed(df: pd.DataFrame, filename: str = "processed_cases.csv") -> Path:
    """Save processed dataset."""
    path = PROCESSED_DIR / filename
    df.to_csv(path, index=False)
    return path


if __name__ == "__main__":
    from src.data_generator import generate_cases

    print("Running preprocessing pipeline...")
    raw_df = generate_cases()
    processed_df, report = preprocess(raw_df)

    print(f"\n=== Data Quality Report ===")
    print(f"Total records:    {report['total_records']}")
    print(f"Duplicates:       {report['duplicates']}")
    print(f"Total missing:    {report['total_missing']}")
    print(f"Range violations: {report['range_violations']}")
    print(f"Data is clean:    {report['is_clean']}")

    print(f"\n=== Normalized Columns Added ===")
    norm_cols = [c for c in processed_df.columns if c.endswith("_norm")]
    print(norm_cols)

    print(f"\n=== Descriptive Statistics ===")
    print(get_descriptive_stats(processed_df).to_string())

    path = save_processed(processed_df)
    print(f"\nSaved processed data → {path}")
