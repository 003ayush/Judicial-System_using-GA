"""
Utility Functions
==================
Common helpers used across the project.
"""

import time
import functools
from pathlib import Path
from typing import Any, Callable


def timer(func: Callable) -> Callable:
    """Decorator that measures and prints execution time."""
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        start = time.time()
        result = func(*args, **kwargs)
        elapsed = time.time() - start
        print(f"[TIMER] {func.__name__}: {elapsed:.3f}s")
        return result
    return wrapper


def ensure_dir(path: Path) -> Path:
    """Create directory if it doesn't exist."""
    path.mkdir(parents=True, exist_ok=True)
    return path


def format_number(n: float, decimals: int = 2) -> str:
    """Format a number with commas and specified decimal places."""
    if abs(n) >= 1e6:
        return f"{n/1e6:.{decimals}f}M"
    elif abs(n) >= 1e3:
        return f"{n/1e3:.{decimals}f}K"
    else:
        return f"{n:.{decimals}f}"


def format_duration(seconds: float) -> str:
    """Format seconds into a readable duration string."""
    if seconds < 1:
        return f"{seconds*1000:.0f}ms"
    elif seconds < 60:
        return f"{seconds:.2f}s"
    else:
        mins = int(seconds // 60)
        secs = seconds % 60
        return f"{mins}m {secs:.1f}s"


ACADEMIC_DISCLAIMER = """
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
⚠️  ACADEMIC RESEARCH PROTOTYPE — NOT FOR OPERATIONAL USE

This system is an explainable decision-support prototype. It uses synthetic data and does NOT:
  • Decide guilt or innocence
  • Predict verdicts or recommend sentences
  • Replace judicial decision-making
  • Represent actual court statistics

All results are based on synthetic data and must NOT be interpreted
as evidence of actual judicial system improvement.
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
"""
