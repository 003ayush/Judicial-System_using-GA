"""
Configuration Module
====================
Single source of truth for all configurable parameters.
Every coefficient, weight, and hyperparameter is defined here
so experiments are reproducible and auditable.
"""

import os
from pathlib import Path

# ============================================================
# PATH CONFIGURATION
# ============================================================
PROJECT_ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = PROJECT_ROOT / "data"
RAW_DIR = DATA_DIR / "raw"
PROCESSED_DIR = DATA_DIR / "processed"
RESULTS_DIR = PROJECT_ROOT / "results"
FIGURES_DIR = RESULTS_DIR / "figures"
TABLES_DIR = RESULTS_DIR / "tables"

# Create directories on import
for d in [RAW_DIR, PROCESSED_DIR, FIGURES_DIR, TABLES_DIR]:
    d.mkdir(parents=True, exist_ok=True)

# ============================================================
# DATASET CONFIGURATION
# ============================================================
RANDOM_SEED = 42
NUM_CASES = 200

CASE_TYPES = ["Civil", "Criminal", "Family", "Commercial", "Constitutional"]
CASE_TYPE_WEIGHTS = [0.30, 0.25, 0.20, 0.15, 0.10]  # Probability weights

# Feature ranges (min, max) — used by data generator
FEATURE_RANGES = {
    "age_years":              (0.1, 15.0),   # Years pending
    "severity":               (1, 10),        # 1=minor, 10=critical
    "complexity":             (1, 10),        # 1=simple, 10=very complex
    "public_interest":        (1, 10),        # 1=private, 10=national interest
    "vulnerability":          (1, 10),        # 1=low urgency, 10=extreme
    "hearing_duration":       (0.5, 8.0),     # Hours per hearing
    "target_day":             (1, 60),        # Ideal completion within N days
    "pending_documents":      (0, 20),        # Outstanding documents
    "historical_adjournments": (0, 30),       # Past adjournments
}

SYNTHETIC_CSV = DATA_DIR / "synthetic_cases.csv"

# ============================================================
# FUZZY INFERENCE CONFIGURATION
# ============================================================
# Input universe ranges (normalized 0–10 scale for all inputs)
FUZZY_INPUT_RANGE = (0, 10)
FUZZY_OUTPUT_RANGE = (0, 100)

# Membership function parameters: (label, type, params)
# Triangular: (a, b, c)  — rise-peak-fall
# Trapezoidal: (a, b, c, d) — rise-flat_start-flat_end-fall
FUZZY_INPUT_MFS = {
    "Low":    ("trapezoidal", (0, 0, 2, 4)),
    "Medium": ("triangular",  (2, 5, 8)),
    "High":   ("trapezoidal", (6, 8, 10, 10)),
}

FUZZY_OUTPUT_MFS = {
    "Very_Low":  ("trapezoidal", (0, 0, 10, 20)),
    "Low":       ("triangular",  (10, 25, 40)),
    "Medium":    ("triangular",  (30, 50, 70)),
    "High":      ("triangular",  (60, 75, 90)),
    "Very_High": ("trapezoidal", (80, 90, 100, 100)),
}

# Fuzzy input variable names (must match preprocessed column names)
FUZZY_INPUTS = [
    "age_years",
    "severity",
    "complexity",
    "public_interest",
    "vulnerability",
]

# ============================================================
# GENETIC ALGORITHM CONFIGURATION
# ============================================================
GA_POPULATION_SIZE = 80
GA_GENERATIONS = 150
GA_CROSSOVER_RATE = 0.85
GA_MUTATION_RATE = 0.15
GA_TOURNAMENT_SIZE = 5
GA_ELITISM_COUNT = 2

# ============================================================
# OBJECTIVE FUNCTION CONFIGURATION
# ============================================================
# Composite objective: lower is better
#   f = w1 * priority_weighted_completion
#     + w2 * lateness_penalty
#     + w3 * capacity_penalty
#     + w4 * concentration_penalty

OBJECTIVE_WEIGHTS = {
    "priority_weighted_completion": 1.0,
    "lateness_penalty":            2.0,
    "capacity_penalty":            0.5,
    "concentration_penalty":       0.3,
}

# Hearing capacity per day (hours)
DAILY_CAPACITY_HOURS = 8.0

# ============================================================
# EXPERIMENT CONFIGURATION
# ============================================================
REPEATED_TRIAL_SEEDS = list(range(42, 52))  # 10 trials
SENSITIVITY_PARAMS = {
    "mutation_rate": [0.01, 0.05, 0.10, 0.15, 0.20, 0.30],
    "population_size": [20, 40, 60, 80, 100, 150],
    "generations": [50, 100, 150, 200, 300],
    "crossover_rate": [0.5, 0.6, 0.7, 0.8, 0.9, 0.95],
}
