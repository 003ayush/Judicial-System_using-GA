# Judicial Case Prioritization AI: UI Explanation Guide

This guide provides a step-by-step, simple explanation of every page and component in our Streamlit UI. Use this as your script or reference when presenting your demo!

## 1. 📊 Dashboard (The Overview Page)
**Purpose:** To give a high-level summary of the entire court backlog and how the system is managing it.

- **Hero Banner & Disclaimer:** Welcomes the user, explains that the system uses "Mamdani Fuzzy Logic" and "Genetic Algorithms", and notes that this is an AI advisory prototype (it doesn't replace human judges!).
- **4-Step Pipeline Bar:** Explains the workflow simply: 
  1. Profile cases
  2. Score urgency (Fuzzy FIS)
  3. Optimize schedule (GA)
  4. Compare benchmarks.
- **Top Metric Cards (KPIs):** Four big numbers at the top:
  - **Total Pending Cases:** Total cases in the system (200 cases).
  - **Average Urgency Score:** The average priority score calculated by the AI (out of 100).
  - **Urgent & Critical Cases:** How many cases need immediate attention (Score > 60).
  - **Total Hearing Time:** Total hours needed to clear the backlog.
- **Priority Distribution Chart (Left):** A colorful histogram showing how many cases fall into each priority bracket, grouped by type (Civil, Criminal, etc.).
- **Docket Composition Chart (Right):** A bar chart showing exactly how many cases exist for each category and their total hearing hours.
- **Top 10 Urgent Cases Queue:** A table displaying the absolute top 10 most critical cases that the AI says must be heard first, complete with badges like "CRITICAL URGENCY" or "HIGH PRIORITY".

---

## 2. 📁 Case Data
**Purpose:** To let the user explore, filter, and generate the raw synthetic data (court cases) that the AI is processing.

- **Upload Custom Docket (CSV):** You can upload your own custom list of court cases via a `.csv` file. The AI will instantly analyze and prioritize your custom docket!
- **Docket Generation Settings (Expander):** You can also use sliders to generate a brand new set of synthetic cases (e.g., change it from 200 to 500 cases) by clicking "Generate Docket". 
- **Filters Bar:** Dropdowns to filter the table by Case Category (e.g., only show "Criminal") or by Priority Tier (e.g., only show "Critical Urgency"). You can also search by Case ID.
- **KPI Row:** Shows quick stats for your filtered view (e.g., average age of the filtered cases).
- **Data Table:** The actual spreadsheet view of the cases with columns like Age, Severity, Complexity, etc.
- **Export Button:** Lets the user download the filtered data as a `.csv` file.
- **Detailed Analytical Tabs (Bottom):**
  - *Descriptive Statistics:* Mathematical summary (mean, min, max) of the cases.
  - *Feature Glossary:* Defines what each column means (e.g., what "Severity" actually measures).
  - *Data Quality Audit:* Runs a quick check to make sure the data has no errors or missing values.

---

## 3. 🧠 AI Evaluator (The "Judge" AI)
**Purpose:** To show exactly *how* the AI calculates a priority score. This proves the AI is not a "black box" and can be understood by humans.

- **Interactive Case Calculator:** 
  - **Presets:** Four buttons (e.g., "Elderly Land Dispute", "Constitutional Challenge") that instantly fill in realistic data.
  - **Sliders:** 5 sliders you can drag to simulate a case: Pendency Age, Severity, Complexity, Litigant Vulnerability, and Public Interest.
- **Visual Priority Meter Card:** A massive visual gauge that updates in real-time as you move the sliders. It outputs the exact score (e.g., 72.4) and gives it a tier (e.g., "HIGH PRIORITY").
- **Explainable AI Decision Breakdown:** A text box that writes out a plain-English explanation. For example: *"This case is HIGH PRIORITY primarily due to extreme litigant vulnerability and high severity..."*
- **Step-by-Step Inference Audit (Expander):** For technical folks, this dropdown shows the exact math—which fuzzy rules fired and their strengths.
- **Complete Judicial Rule Base (Tab 2):** A table showing all 16 IF-THEN rules programmed into the brain of the AI (e.g., "IF age is High AND severity is High, THEN priority is Very_High").

---

## 4. 🧬 AI Scheduler (The "Calendar Scheduler" AI)
**Purpose:** To take all the cases, look at their priorities, and figure out the absolute best daily timetable without exceeding court hours.

- **Optimization Presets:** Buttons to choose how hard the algorithm should think ("Fast Demo" vs "Deep Search").
- **Advanced Hyperparameter Tuning (Expander):** Lets you change Genetic Algorithm variables like Population Size, Generations, and Mutation Rate.
- **"Run Timetable Optimization" Button:** The most important button! Clicking this runs the Genetic Algorithm. A progress bar appears as it evolves the best schedule.
- **Success Banner:** Once finished, it announces how much the AI improved the schedule compared to a basic "First-In, First-Out" approach.
- **Interactive Daily Court Calendar (Tab 1):** The final output! A complete daily timetable showing exactly which case goes to which bench on which day, down to the hour.
- **Baseline Method Comparison (Tab 2):** A table comparing our Genetic Algorithm to other dumb methods.
- **GA Convergence Curve (Tab 3):** A graph showing how the Genetic Algorithm "learned" and improved over each generation.
- **Penalty Cost Breakdown (Tab 4):** Shows the exact mathematical penalties (e.g., Lateness Penalty, Capacity Penalty) the algorithm tried to minimize.
