"""
Main Experiment Runner
=======================
Full experiment pipeline:
  1. Generate synthetic dataset
  2. Preprocess and normalize
  3. Compute fuzzy priority scores
  4. Run all scheduling methods (baselines + GA)
  5. Compare results
  6. Generate figures
  7. Save results to CSV

Usage:
    python experiments/run_experiment.py
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

import numpy as np
import pandas as pd

from src.config import RANDOM_SEED, FIGURES_DIR, TABLES_DIR, RESULTS_DIR
from src.data_generator import generate_cases, save_dataset
from src.preprocessing import preprocess, save_processed
from src.fuzzy_engine import compute_all_priorities
from src.evaluation import compare_methods
from src.visualization import (
    plot_input_membership_functions, plot_output_membership_functions,
    plot_priority_distribution, plot_comparison_bar, plot_convergence,
)


def main():
    print("=" * 60)
    print("JUDICIAL CASE PRIORITIZATION - MAIN EXPERIMENT")
    print("=" * 60)

    # Step 1: Generate dataset
    print("\n[1/6] Generating synthetic dataset...")
    df = generate_cases()
    save_dataset(df)
    print(f"  Generated {len(df)} cases")
    print(f"  Case types: {df['case_type'].value_counts().to_dict()}")

    # Step 2: Preprocess
    print("\n[2/6] Preprocessing...")
    processed, report = preprocess(df)
    save_processed(processed)
    print(f"  Data clean: {report['is_clean']}")

    # Step 3: Compute fuzzy priorities
    print("\n[3/6] Computing fuzzy priority scores...")
    scores = compute_all_priorities(processed)
    processed['priority_score'] = scores
    save_processed(processed, "processed_with_priorities.csv")
    print(f"  Priority range: [{min(scores):.2f}, {max(scores):.2f}]")
    print(f"  Priority mean:  {np.mean(scores):.2f} +/- {np.std(scores):.2f}")

    # Step 4: Prepare arrays for optimization
    print("\n[4/6] Running scheduling methods...")
    ages = processed['age_years'].values
    priorities = np.array(scores)
    durations = processed['hearing_duration'].values
    target_days = processed['target_day'].values
    case_types = processed['case_type'].values

    # Step 5: Compare methods
    results = compare_methods(
        ages, priorities, durations, target_days, case_types, seed=RANDOM_SEED
    )

    # Print results
    print("\n" + "=" * 60)
    print("RESULTS COMPARISON")
    print("=" * 60)
    print(f"{'Method':<25} {'Objective':>12} {'Runtime':>10} {'Avg Top Pos':>12}")
    print("-" * 60)
    for r in sorted(results, key=lambda x: x['objective']):
        print(f"{r['method']:<25} {r['objective']:>12,.1f} {r['runtime']:>9.3f}s {r['avg_top_priority_position']:>11.1f}")

    # Save results table
    results_df = pd.DataFrame([{
        "Method": r["method"],
        "Objective": round(r["objective"], 2),
        "Runtime (s)": round(r["runtime"], 4),
        "Avg Top-20% Position": round(r["avg_top_priority_position"], 2),
        "PWC": round(r["objective_components"]["priority_weighted_completion"], 2),
        "Lateness": round(r["objective_components"]["lateness_penalty"], 2),
        "Capacity": round(r["objective_components"]["capacity_penalty"], 2),
    } for r in results])
    results_df.to_csv(TABLES_DIR / "comparison_results.csv", index=False)
    print(f"\nResults saved to {TABLES_DIR / 'comparison_results.csv'}")

    # Step 6: Generate figures
    print("\n[5/6] Generating figures...")
    plot_input_membership_functions()
    plot_output_membership_functions()
    plot_priority_distribution(priorities, case_types)
    plot_comparison_bar(results)

    ga_result = [r for r in results if r["method"] == "Genetic Algorithm"][0]
    if "convergence_history" in ga_result:
        plot_convergence(
            ga_result["convergence_history"],
            ga_result.get("avg_fitness_history"),
        )

    print(f"  Figures saved to {FIGURES_DIR}")

    # Summary
    print("\n" + "=" * 60)
    print("EXPERIMENT COMPLETE")
    print("=" * 60)

    best = min(results, key=lambda x: x['objective'])
    print(f"  Best method: {best['method']}")
    print(f"  Best objective: {best['objective']:,.2f}")

    return results


if __name__ == "__main__":
    main()
