"""
Repeated Trials Runner
========================
Runs experiments with multiple random seeds and collects statistical summaries.

Usage:
    python experiments/run_repeated_trials.py
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

import numpy as np
import pandas as pd

from src.config import RANDOM_SEED, REPEATED_TRIAL_SEEDS, TABLES_DIR, RESULTS_DIR
from src.data_generator import generate_cases
from src.preprocessing import preprocess
from src.fuzzy_engine import compute_all_priorities
from src.evaluation import run_repeated_trials, compute_trial_statistics
from src.visualization import plot_repeated_trials


def main():
    print("=" * 60)
    print("REPEATED TRIALS EXPERIMENT")
    print("=" * 60)
    print(f"Seeds: {REPEATED_TRIAL_SEEDS}")
    print(f"Number of trials: {len(REPEATED_TRIAL_SEEDS)}")

    # Prepare data (fixed dataset, vary GA seed)
    df = generate_cases(seed=RANDOM_SEED)
    processed, _ = preprocess(df)
    scores = compute_all_priorities(processed)
    processed['priority_score'] = scores

    priorities = np.array(scores)
    ages = processed['age_years'].values
    durations = processed['hearing_duration'].values
    target_days = processed['target_day'].values
    case_types = processed['case_type'].values

    def progress(i, total):
        print(f"  Trial {i}/{total} complete")

    # Run trials
    trial_df = run_repeated_trials(
        ages, priorities, durations, target_days, case_types,
        seeds=REPEATED_TRIAL_SEEDS,
        progress_callback=progress,
    )

    # Statistics
    stats = compute_trial_statistics(trial_df)

    print("\n" + "=" * 60)
    print("STATISTICAL SUMMARY")
    print("=" * 60)
    print(stats.to_string(index=False))

    # Save results
    trial_df.to_csv(TABLES_DIR / "repeated_trials.csv", index=False)
    stats.to_csv(TABLES_DIR / "trial_statistics.csv", index=False)
    print(f"\nTrial data saved to {TABLES_DIR / 'repeated_trials.csv'}")
    print(f"Statistics saved to {TABLES_DIR / 'trial_statistics.csv'}")

    # Plot
    plot_repeated_trials(trial_df)
    print("Box plot saved.")

    # Save experiment summary
    summary = {
        "num_cases": len(df),
        "num_trials": len(REPEATED_TRIAL_SEEDS),
        "seeds": str(REPEATED_TRIAL_SEEDS),
    }
    for _, row in stats.iterrows():
        method = row["method"].replace(" ", "_").lower()
        summary[f"{method}_obj_mean"] = round(row["objective_mean"], 2)
        summary[f"{method}_obj_std"] = round(row["objective_std"], 2)

    summary_df = pd.DataFrame([summary])
    summary_df.to_csv(RESULTS_DIR / "experiment_summary.csv", index=False)
    print(f"Summary saved to {RESULTS_DIR / 'experiment_summary.csv'}")


if __name__ == "__main__":
    main()
