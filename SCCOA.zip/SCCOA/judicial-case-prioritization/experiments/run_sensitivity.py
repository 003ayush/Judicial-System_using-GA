"""
Sensitivity Analysis Runner
=============================
Varies GA parameters one at a time and measures the impact on the objective.

Usage:
    python experiments/run_sensitivity.py
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

import numpy as np
import pandas as pd

from src.config import RANDOM_SEED, SENSITIVITY_PARAMS, TABLES_DIR, FIGURES_DIR
from src.data_generator import generate_cases
from src.preprocessing import preprocess
from src.fuzzy_engine import compute_all_priorities
from src.evaluation import run_sensitivity_analysis
from src.visualization import plot_sensitivity


def main():
    print("=" * 60)
    print("SENSITIVITY ANALYSIS")
    print("=" * 60)

    # Prepare data
    df = generate_cases()
    processed, _ = preprocess(df)
    scores = compute_all_priorities(processed)
    processed['priority_score'] = scores

    priorities = np.array(scores)
    ages = processed['age_years'].values
    durations = processed['hearing_duration'].values
    target_days = processed['target_day'].values
    case_types = processed['case_type'].values

    all_sens = []

    for param_name, param_values in SENSITIVITY_PARAMS.items():
        print(f"\nAnalyzing: {param_name}")
        print(f"  Values: {param_values}")

        sens_df = run_sensitivity_analysis(
            ages, priorities, durations, target_days, case_types,
            param_name=param_name,
            param_values=param_values,
            seed=RANDOM_SEED,
        )

        print(f"  Results:")
        for _, row in sens_df.iterrows():
            print(f"    {param_name}={row['param_value']}: obj={row['objective']:,.1f}, time={row['runtime']:.2f}s")

        plot_sensitivity(sens_df)
        all_sens.append(sens_df)

    # Save combined results
    combined = pd.concat(all_sens, ignore_index=True)
    combined.to_csv(TABLES_DIR / "sensitivity_analysis.csv", index=False)
    print(f"\nAll sensitivity results saved to {TABLES_DIR / 'sensitivity_analysis.csv'}")


if __name__ == "__main__":
    main()
